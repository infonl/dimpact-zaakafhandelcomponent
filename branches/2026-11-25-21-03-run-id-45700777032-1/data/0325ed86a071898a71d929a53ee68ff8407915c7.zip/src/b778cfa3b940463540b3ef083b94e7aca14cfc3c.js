// Generated from: bdd/@zaak/@cmmn/open-formulieren.feature
import { test } from "../../../bdd/fixtures.ts";

test.describe('Open Formulieren', () => {

  test('A submitted form becomes a zaak with its documents', { tag: ['@behandelaar', '@zaak', '@cmmn'] }, async ({ When, Then, And, apiAs, browser, page, testData }) => { 
    await When('a resident submits the form about aansprakelijkstelling with a photo', null, { browser, testData }); 
    await Then('the submission becomes a zaak', null, { page, testData }); 
    await And('the zaak shows the PDF of the submission and the photo', null, { apiAs, page, testData }); 
  });

});

// == technical section ==

test.use({
  $test: [({}, use) => use(test), { scope: 'test', box: true }],
  $uri: [({}, use) => use('bdd/@zaak/@cmmn/open-formulieren.feature'), { scope: 'test', box: true }],
  $bddFileData: [({}, use) => use(bddFileData), { scope: "test", box: true }],
  page: async ({ page, $prompt }, use) => {
    $prompt.setPage(page);
    await use(page);
  },
});

const bddFileData = [ // bdd-data-start
  {"pwTestLine":6,"pickleLine":11,"tags":["@behandelaar","@zaak","@cmmn"],"steps":[{"pwStepLine":7,"gherkinStepLine":12,"keywordType":"Action","textWithKeyword":"When a resident submits the form about aansprakelijkstelling with a photo","stepMatchArguments":[]},{"pwStepLine":8,"gherkinStepLine":13,"keywordType":"Outcome","textWithKeyword":"Then the submission becomes a zaak","stepMatchArguments":[]},{"pwStepLine":9,"gherkinStepLine":14,"keywordType":"Outcome","textWithKeyword":"And the zaak shows the PDF of the submission and the photo","stepMatchArguments":[]}]},
]; // bdd-data-end