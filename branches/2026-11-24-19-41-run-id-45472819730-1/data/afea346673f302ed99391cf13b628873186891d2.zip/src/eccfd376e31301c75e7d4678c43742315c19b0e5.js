// Generated from: bdd/@zaak/@cmmn/zaak-afronden.feature
import { test } from "../../../bdd/fixtures.ts";

test.describe('Zaak afronden', () => {

  test('A behandelaar records a besluit and closes the zaak', { tag: ['@behandelaar', '@zaak', '@cmmn'] }, async ({ Given, When, Then, And, page, testData }) => { 
    await Given('a zaak in behandeling', null, { testData }); 
    await And('the zaak has a document "E2E besluitbrief" of type "besluit"', null, { testData }); 
    await When('I open the zaak', null, { page, testData }); 
    await And('I record a besluit and link the document "E2E besluitbrief"', null, { page, testData }); 
    await Then('the zaak shows the besluit with the document "E2E besluitbrief"', null, { page, testData }); 
    await When('I close the zaak with the resultaat "Toegekend"', null, { page }); 
    await Then('the status is "Afgerond"', null, { page }); 
    await And('the zaak appears in the list of afgehandelde zaken with the resultaat "Toegekend"', null, { page, testData }); 
  });

  test('A recordmanager reopens a closed zaak', { tag: ['@recordmanager', '@zaak', '@cmmn'] }, async ({ Given, When, Then, And, apiAs, page, testData }) => { 
    await Given('a closed zaak with the resultaat "Toegekend"', null, { testData }); 
    await When('I open the zaak', null, { page, testData }); 
    await And('I reopen the zaak with the reason "Bezwaar ontvangen"', null, { page }); 
    await Then('the zaak shows the indicatie "heropend"', null, { page }); 
    await And('the zaak has no resultaat', null, { apiAs, testData }); 
    await And('the zaak is gone from the list of afgehandelde zaken', null, { page, testData }); 
  });

});

// == technical section ==

test.use({
  $test: [({}, use) => use(test), { scope: 'test', box: true }],
  $uri: [({}, use) => use('bdd/@zaak/@cmmn/zaak-afronden.feature'), { scope: 'test', box: true }],
  $bddFileData: [({}, use) => use(bddFileData), { scope: "test", box: true }],
});

const bddFileData = [ // bdd-data-start
  {"pwTestLine":6,"pickleLine":15,"tags":["@behandelaar","@zaak","@cmmn"],"steps":[{"pwStepLine":7,"gherkinStepLine":16,"keywordType":"Context","textWithKeyword":"Given a zaak in behandeling","stepMatchArguments":[]},{"pwStepLine":8,"gherkinStepLine":17,"keywordType":"Context","textWithKeyword":"And the zaak has a document \"E2E besluitbrief\" of type \"besluit\"","stepMatchArguments":[{"group":{"start":24,"value":"\"E2E besluitbrief\"","children":[{"start":25,"value":"E2E besluitbrief","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"},{"group":{"start":51,"value":"\"besluit\"","children":[{"start":52,"value":"besluit"}]},"parameterTypeName":"seeded"}]},{"pwStepLine":9,"gherkinStepLine":18,"keywordType":"Action","textWithKeyword":"When I open the zaak","stepMatchArguments":[]},{"pwStepLine":10,"gherkinStepLine":19,"keywordType":"Action","textWithKeyword":"And I record a besluit and link the document \"E2E besluitbrief\"","stepMatchArguments":[{"group":{"start":41,"value":"\"E2E besluitbrief\"","children":[{"start":42,"value":"E2E besluitbrief","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":11,"gherkinStepLine":20,"keywordType":"Outcome","textWithKeyword":"Then the zaak shows the besluit with the document \"E2E besluitbrief\"","stepMatchArguments":[{"group":{"start":45,"value":"\"E2E besluitbrief\"","children":[{"start":46,"value":"E2E besluitbrief","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":12,"gherkinStepLine":21,"keywordType":"Action","textWithKeyword":"When I close the zaak with the resultaat \"Toegekend\"","stepMatchArguments":[{"group":{"start":36,"value":"\"Toegekend\"","children":[{"start":37,"value":"Toegekend"}]},"parameterTypeName":"seeded"}]},{"pwStepLine":13,"gherkinStepLine":22,"keywordType":"Outcome","textWithKeyword":"Then the status is \"Afgerond\"","stepMatchArguments":[{"group":{"start":14,"value":"\"Afgerond\"","children":[{"start":15,"value":"Afgerond","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":14,"gherkinStepLine":23,"keywordType":"Outcome","textWithKeyword":"And the zaak appears in the list of afgehandelde zaken with the resultaat \"Toegekend\"","stepMatchArguments":[{"group":{"start":70,"value":"\"Toegekend\"","children":[{"start":71,"value":"Toegekend"}]},"parameterTypeName":"seeded"}]}]},
  {"pwTestLine":17,"pickleLine":26,"tags":["@recordmanager","@zaak","@cmmn"],"steps":[{"pwStepLine":18,"gherkinStepLine":27,"keywordType":"Context","textWithKeyword":"Given a closed zaak with the resultaat \"Toegekend\"","stepMatchArguments":[{"group":{"start":33,"value":"\"Toegekend\"","children":[{"start":34,"value":"Toegekend"}]},"parameterTypeName":"seeded"}]},{"pwStepLine":19,"gherkinStepLine":28,"keywordType":"Action","textWithKeyword":"When I open the zaak","stepMatchArguments":[]},{"pwStepLine":20,"gherkinStepLine":29,"keywordType":"Action","textWithKeyword":"And I reopen the zaak with the reason \"Bezwaar ontvangen\"","stepMatchArguments":[{"group":{"start":34,"value":"\"Bezwaar ontvangen\"","children":[{"start":35,"value":"Bezwaar ontvangen","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":21,"gherkinStepLine":30,"keywordType":"Outcome","textWithKeyword":"Then the zaak shows the indicatie \"heropend\"","stepMatchArguments":[{"group":{"start":29,"value":"\"heropend\"","children":[{"start":30,"value":"heropend","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":22,"gherkinStepLine":31,"keywordType":"Outcome","textWithKeyword":"And the zaak has no resultaat","stepMatchArguments":[]},{"pwStepLine":23,"gherkinStepLine":32,"keywordType":"Outcome","textWithKeyword":"And the zaak is gone from the list of afgehandelde zaken","stepMatchArguments":[]}]},
]; // bdd-data-end