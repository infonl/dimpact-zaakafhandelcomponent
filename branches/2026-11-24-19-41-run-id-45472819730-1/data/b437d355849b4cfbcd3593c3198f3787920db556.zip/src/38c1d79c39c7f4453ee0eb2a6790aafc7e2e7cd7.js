// Generated from: bdd/@zaak/@cmmn/documenten-en-ontvangstbevestiging.feature
import { test } from "../../../bdd/fixtures.ts";

test.describe('Documenten en ontvangstbevestiging', () => {

  test.beforeEach('Background', async ({ Given, testData }, testInfo) => { if (testInfo.error) return;
    await Given('a zaak in intake with a person as initiator', null, { testData }); 
  });
  
  test('A behandelaar adds a document and confirms receipt', { tag: ['@behandelaar', '@zaak', '@cmmn'] }, async ({ When, Then, And, accountOfRole, apiAs, page, testData }) => { 
    await When('I open the zaak', null, { page, testData }); 
    await And('I add the document "brief.pdf" with the titel "E2E brief" and the type "brief"', null, { page, testData }); 
    await Then('the document "E2E brief" is listed at the zaak', null, { page, testData }); 
    await And('the document "E2E brief" shows the titel, the taal, the auteur and the creatiedatum', null, { accountOfRole, page, testData }); 
    await When('I send the ontvangstbevestiging to the initiator', null, { page, testData }); 
    await Then('the ontvangstbevestiging is stored at the zaak as a PDF document', null, { apiAs, page, testData }); 
    await And('the zaak shows that the ontvangstbevestiging is sent', null, { page }); 
    await When('I record that the document "E2E brief" was sent by post today', null, { page, testData }); 
    await Then('the document "E2E brief" shows the indicatie "is verzonden"', null, { page, testData }); 
  });

});

// == technical section ==

test.use({
  $test: [({}, use) => use(test), { scope: 'test', box: true }],
  $uri: [({}, use) => use('bdd/@zaak/@cmmn/documenten-en-ontvangstbevestiging.feature'), { scope: 'test', box: true }],
  $bddFileData: [({}, use) => use(bddFileData), { scope: "test", box: true }],
});

const bddFileData = [ // bdd-data-start
  {"pwTestLine":10,"pickleLine":14,"tags":["@behandelaar","@zaak","@cmmn"],"steps":[{"pwStepLine":7,"gherkinStepLine":12,"keywordType":"Context","textWithKeyword":"Given a zaak in intake with a person as initiator","isBg":true,"stepMatchArguments":[]},{"pwStepLine":11,"gherkinStepLine":15,"keywordType":"Action","textWithKeyword":"When I open the zaak","stepMatchArguments":[]},{"pwStepLine":12,"gherkinStepLine":16,"keywordType":"Action","textWithKeyword":"And I add the document \"brief.pdf\" with the titel \"E2E brief\" and the type \"brief\"","stepMatchArguments":[{"group":{"start":19,"value":"\"brief.pdf\"","children":[{"start":20,"value":"brief.pdf","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"},{"group":{"start":46,"value":"\"E2E brief\"","children":[{"start":47,"value":"E2E brief","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"},{"group":{"start":71,"value":"\"brief\"","children":[{"start":72,"value":"brief"}]},"parameterTypeName":"seeded"}]},{"pwStepLine":13,"gherkinStepLine":17,"keywordType":"Outcome","textWithKeyword":"Then the document \"E2E brief\" is listed at the zaak","stepMatchArguments":[{"group":{"start":13,"value":"\"E2E brief\"","children":[{"start":14,"value":"E2E brief","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":14,"gherkinStepLine":18,"keywordType":"Outcome","textWithKeyword":"And the document \"E2E brief\" shows the titel, the taal, the auteur and the creatiedatum","stepMatchArguments":[{"group":{"start":13,"value":"\"E2E brief\"","children":[{"start":14,"value":"E2E brief","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":15,"gherkinStepLine":19,"keywordType":"Action","textWithKeyword":"When I send the ontvangstbevestiging to the initiator","stepMatchArguments":[]},{"pwStepLine":16,"gherkinStepLine":20,"keywordType":"Outcome","textWithKeyword":"Then the ontvangstbevestiging is stored at the zaak as a PDF document","stepMatchArguments":[]},{"pwStepLine":17,"gherkinStepLine":21,"keywordType":"Outcome","textWithKeyword":"And the zaak shows that the ontvangstbevestiging is sent","stepMatchArguments":[]},{"pwStepLine":18,"gherkinStepLine":22,"keywordType":"Action","textWithKeyword":"When I record that the document \"E2E brief\" was sent by post today","stepMatchArguments":[{"group":{"start":27,"value":"\"E2E brief\"","children":[{"start":28,"value":"E2E brief","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":19,"gherkinStepLine":23,"keywordType":"Outcome","textWithKeyword":"Then the document \"E2E brief\" shows the indicatie \"is verzonden\"","stepMatchArguments":[{"group":{"start":13,"value":"\"E2E brief\"","children":[{"start":14,"value":"E2E brief","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"},{"group":{"start":45,"value":"\"is verzonden\"","children":[{"start":46,"value":"is verzonden","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]}]},
]; // bdd-data-end