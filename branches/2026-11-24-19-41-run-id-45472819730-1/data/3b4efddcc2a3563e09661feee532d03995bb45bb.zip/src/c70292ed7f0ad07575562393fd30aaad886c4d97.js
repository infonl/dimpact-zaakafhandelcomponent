// Generated from: bdd/@zaak/@cmmn/taak-afhandelen.feature
import { test } from "../../../bdd/fixtures.ts";

test.describe('Taak afhandelen', () => {

  test.beforeEach('Background', async ({ Given, testData }, testInfo) => { if (testInfo.error) return;
    await Given('a zaak in behandeling', null, { testData }); 
  });
  
  test('A behandelaar starts and completes a Goedkeuren task', { tag: ['@behandelaar', '@zaak', '@cmmn'] }, async ({ When, Then, And, accountOfRole, page, testData }) => { 
    await When('I open the zaak', null, { page, testData }); 
    await And('I start the task "Goedkeuren" and assign it to myself', null, { accountOfRole, page, testData }); 
    await Then('the task "Goedkeuren" appears in my takenlijst', null, { page, testData }); 
    await When('I open the task "Goedkeuren" from my takenlijst', null, { page, testData }); 
    await And('I complete the task with the decision "Akkoord" and the toelichting "E2E akkoord"', null, { page }); 
    await Then('the task "Goedkeuren" is gone from my takenlijst', null, { page, testData }); 
    await And('the zaak lists the task "Goedkeuren" as afgerond', null, { page, testData }); 
  });

});

// == technical section ==

test.use({
  $test: [({}, use) => use(test), { scope: 'test', box: true }],
  $uri: [({}, use) => use('bdd/@zaak/@cmmn/taak-afhandelen.feature'), { scope: 'test', box: true }],
  $bddFileData: [({}, use) => use(bddFileData), { scope: "test", box: true }],
});

const bddFileData = [ // bdd-data-start
  {"pwTestLine":10,"pickleLine":14,"tags":["@behandelaar","@zaak","@cmmn"],"steps":[{"pwStepLine":7,"gherkinStepLine":12,"keywordType":"Context","textWithKeyword":"Given a zaak in behandeling","isBg":true,"stepMatchArguments":[]},{"pwStepLine":11,"gherkinStepLine":15,"keywordType":"Action","textWithKeyword":"When I open the zaak","stepMatchArguments":[]},{"pwStepLine":12,"gherkinStepLine":16,"keywordType":"Action","textWithKeyword":"And I start the task \"Goedkeuren\" and assign it to myself","stepMatchArguments":[{"group":{"start":17,"value":"\"Goedkeuren\"","children":[{"start":18,"value":"Goedkeuren","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":13,"gherkinStepLine":17,"keywordType":"Outcome","textWithKeyword":"Then the task \"Goedkeuren\" appears in my takenlijst","stepMatchArguments":[{"group":{"start":9,"value":"\"Goedkeuren\"","children":[{"start":10,"value":"Goedkeuren","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":14,"gherkinStepLine":18,"keywordType":"Action","textWithKeyword":"When I open the task \"Goedkeuren\" from my takenlijst","stepMatchArguments":[{"group":{"start":16,"value":"\"Goedkeuren\"","children":[{"start":17,"value":"Goedkeuren","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":15,"gherkinStepLine":19,"keywordType":"Action","textWithKeyword":"And I complete the task with the decision \"Akkoord\" and the toelichting \"E2E akkoord\"","stepMatchArguments":[{"group":{"start":38,"value":"\"Akkoord\"","children":[{"start":39,"value":"Akkoord","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"},{"group":{"start":68,"value":"\"E2E akkoord\"","children":[{"start":69,"value":"E2E akkoord","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":16,"gherkinStepLine":20,"keywordType":"Outcome","textWithKeyword":"Then the task \"Goedkeuren\" is gone from my takenlijst","stepMatchArguments":[{"group":{"start":9,"value":"\"Goedkeuren\"","children":[{"start":10,"value":"Goedkeuren","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":17,"gherkinStepLine":21,"keywordType":"Outcome","textWithKeyword":"And the zaak lists the task \"Goedkeuren\" as afgerond","stepMatchArguments":[{"group":{"start":24,"value":"\"Goedkeuren\"","children":[{"start":25,"value":"Goedkeuren","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]}]},
]; // bdd-data-end