// Generated from: bdd/@zaak/@cmmn/werkvoorraad-verdelen.feature
import { test } from "../../../bdd/fixtures.ts";

test.describe('Werkvoorraad verdelen en vrijgeven', () => {

  test('A coordinator assigns and releases zaken', { tag: ['@coordinator', '@zaak', '@cmmn'] }, async ({ Given, When, Then, And, accountOfRole, page, testData }) => { 
    await Given('3 zaken for groep "Test group behandelaars domein test 1" without a behandelaar', null, { testData }); 
    await When('I open the zaken werkvoorraad', null, { page }); 
    await And('I select the 3 zaken', null, { page, testData }); 
    await And('I assign them to groep "Test group behandelaars domein test 1" and to the behandelaar', null, { accountOfRole, page }); 
    await Then('I see the message "3 zaken worden verdeeld..."', null, { page }); 
    await And('the 3 zaken show the behandelaar without a page reload', null, { accountOfRole, page, testData }); 
    await When('I select the 3 zaken', null, { page, testData }); 
    await And('I release them with the reason "Behandelaar met verlof"', null, { page }); 
    await Then('I see the message "3 zaken worden vrijgegeven..."', null, { page }); 
    await And('the 3 zaken show no behandelaar without a page reload', null, { accountOfRole, page, testData }); 
  });

  test('A coordinator assigns taken', { tag: ['@coordinator', '@zaak', '@cmmn'] }, async ({ Given, When, Then, And, accountOfRole, page, testData }) => { 
    await Given('3 open taken for groep "Test group behandelaars domein test 1" without a behandelaar', null, { testData }); 
    await When('I open the taken werkvoorraad', null, { page }); 
    await And('I select the 3 taken', null, { page, testData }); 
    await And('I assign them to the behandelaar', null, { accountOfRole, page, testData }); 
    await Then('the 3 taken show the behandelaar without a page reload', null, { accountOfRole, page }); 
  });

  test('A behandelaar picks up a zaak of the groep', { tag: ['@behandelaar', '@zaak', '@cmmn'] }, async ({ Given, When, Then, And, accountOfRole, page, testData }) => { 
    await Given('a zaak for groep "Test group behandelaars domein test 1" without a behandelaar', null, { testData }); 
    await When('I open the zaken werkvoorraad', null, { page }); 
    await And('I assign the zaak to myself', null, { accountOfRole, page, testData }); 
    await Then('the zaak shows me as behandelaar', null, { accountOfRole, page, testData }); 
    await And('the zaak appears in my zaken', null, { page, testData }); 
  });

});

// == technical section ==

test.use({
  $test: [({}, use) => use(test), { scope: 'test', box: true }],
  $uri: [({}, use) => use('bdd/@zaak/@cmmn/werkvoorraad-verdelen.feature'), { scope: 'test', box: true }],
  $bddFileData: [({}, use) => use(bddFileData), { scope: "test", box: true }],
});

const bddFileData = [ // bdd-data-start
  {"pwTestLine":6,"pickleLine":11,"tags":["@coordinator","@zaak","@cmmn"],"steps":[{"pwStepLine":7,"gherkinStepLine":12,"keywordType":"Context","textWithKeyword":"Given 3 zaken for groep \"Test group behandelaars domein test 1\" without a behandelaar","stepMatchArguments":[{"group":{"start":0,"value":"3"},"parameterTypeName":"int"},{"group":{"start":18,"value":"\"Test group behandelaars domein test 1\"","children":[{"start":19,"value":"Test group behandelaars domein test 1"}]},"parameterTypeName":"seeded"}]},{"pwStepLine":8,"gherkinStepLine":13,"keywordType":"Action","textWithKeyword":"When I open the zaken werkvoorraad","stepMatchArguments":[]},{"pwStepLine":9,"gherkinStepLine":14,"keywordType":"Action","textWithKeyword":"And I select the 3 zaken","stepMatchArguments":[{"group":{"start":13,"value":"3"},"parameterTypeName":"int"}]},{"pwStepLine":10,"gherkinStepLine":15,"keywordType":"Action","textWithKeyword":"And I assign them to groep \"Test group behandelaars domein test 1\" and to the behandelaar","stepMatchArguments":[{"group":{"start":23,"value":"\"Test group behandelaars domein test 1\"","children":[{"start":24,"value":"Test group behandelaars domein test 1"}]},"parameterTypeName":"seeded"}]},{"pwStepLine":11,"gherkinStepLine":16,"keywordType":"Outcome","textWithKeyword":"Then I see the message \"3 zaken worden verdeeld...\"","stepMatchArguments":[{"group":{"start":18,"value":"\"3 zaken worden verdeeld...\"","children":[{"start":19,"value":"3 zaken worden verdeeld...","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":12,"gherkinStepLine":17,"keywordType":"Outcome","textWithKeyword":"And the 3 zaken show the behandelaar without a page reload","stepMatchArguments":[{"group":{"start":4,"value":"3"},"parameterTypeName":"int"}]},{"pwStepLine":13,"gherkinStepLine":18,"keywordType":"Action","textWithKeyword":"When I select the 3 zaken","stepMatchArguments":[{"group":{"start":13,"value":"3"},"parameterTypeName":"int"}]},{"pwStepLine":14,"gherkinStepLine":19,"keywordType":"Action","textWithKeyword":"And I release them with the reason \"Behandelaar met verlof\"","stepMatchArguments":[{"group":{"start":31,"value":"\"Behandelaar met verlof\"","children":[{"start":32,"value":"Behandelaar met verlof","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":15,"gherkinStepLine":20,"keywordType":"Outcome","textWithKeyword":"Then I see the message \"3 zaken worden vrijgegeven...\"","stepMatchArguments":[{"group":{"start":18,"value":"\"3 zaken worden vrijgegeven...\"","children":[{"start":19,"value":"3 zaken worden vrijgegeven...","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":16,"gherkinStepLine":21,"keywordType":"Outcome","textWithKeyword":"And the 3 zaken show no behandelaar without a page reload","stepMatchArguments":[{"group":{"start":4,"value":"3"},"parameterTypeName":"int"}]}]},
  {"pwTestLine":19,"pickleLine":24,"tags":["@coordinator","@zaak","@cmmn"],"steps":[{"pwStepLine":20,"gherkinStepLine":25,"keywordType":"Context","textWithKeyword":"Given 3 open taken for groep \"Test group behandelaars domein test 1\" without a behandelaar","stepMatchArguments":[{"group":{"start":0,"value":"3"},"parameterTypeName":"int"},{"group":{"start":23,"value":"\"Test group behandelaars domein test 1\"","children":[{"start":24,"value":"Test group behandelaars domein test 1"}]},"parameterTypeName":"seeded"}]},{"pwStepLine":21,"gherkinStepLine":26,"keywordType":"Action","textWithKeyword":"When I open the taken werkvoorraad","stepMatchArguments":[]},{"pwStepLine":22,"gherkinStepLine":27,"keywordType":"Action","textWithKeyword":"And I select the 3 taken","stepMatchArguments":[{"group":{"start":13,"value":"3"},"parameterTypeName":"int"}]},{"pwStepLine":23,"gherkinStepLine":28,"keywordType":"Action","textWithKeyword":"And I assign them to the behandelaar","stepMatchArguments":[]},{"pwStepLine":24,"gherkinStepLine":29,"keywordType":"Outcome","textWithKeyword":"Then the 3 taken show the behandelaar without a page reload","stepMatchArguments":[{"group":{"start":4,"value":"3"},"parameterTypeName":"int"}]}]},
  {"pwTestLine":27,"pickleLine":32,"tags":["@behandelaar","@zaak","@cmmn"],"steps":[{"pwStepLine":28,"gherkinStepLine":33,"keywordType":"Context","textWithKeyword":"Given a zaak for groep \"Test group behandelaars domein test 1\" without a behandelaar","stepMatchArguments":[{"group":{"start":17,"value":"\"Test group behandelaars domein test 1\"","children":[{"start":18,"value":"Test group behandelaars domein test 1"}]},"parameterTypeName":"seeded"}]},{"pwStepLine":29,"gherkinStepLine":34,"keywordType":"Action","textWithKeyword":"When I open the zaken werkvoorraad","stepMatchArguments":[]},{"pwStepLine":30,"gherkinStepLine":35,"keywordType":"Action","textWithKeyword":"And I assign the zaak to myself","stepMatchArguments":[]},{"pwStepLine":31,"gherkinStepLine":36,"keywordType":"Outcome","textWithKeyword":"Then the zaak shows me as behandelaar","stepMatchArguments":[]},{"pwStepLine":32,"gherkinStepLine":37,"keywordType":"Outcome","textWithKeyword":"And the zaak appears in my zaken","stepMatchArguments":[]}]},
]; // bdd-data-end