// Generated from: bdd/@zaak/@cmmn/zaken-koppelen.feature
import { test } from "../../../bdd/fixtures.ts";

test.describe('Zaken koppelen', () => {

  test.beforeEach('Background', async ({ Given, And, testData }, testInfo) => { if (testInfo.error) return;
    await Given('a zaak "E2E hoofdzaak" in behandeling', null, { testData }); 
    await And('a zaak "E2E deelzaak" in behandeling, of a zaaktype that the hoofdzaak allows as deelzaak', null, { testData }); 
  });
  
  test('A deelzaak must close before its hoofdzaak', { tag: ['@behandelaar', '@zaak', '@cmmn'] }, async ({ When, Then, And, page, testData }) => { 
    await When('I open the zaak "E2E hoofdzaak"', null, { page, testData }); 
    await And('I link the zaak "E2E deelzaak" as deelzaak', null, { page, testData }); 
    await Then('the zaak "E2E hoofdzaak" shows "E2E deelzaak" under "Gerelateerde zaken"', null, { page, testData }); 
    await And('the zaak "E2E deelzaak" shows "E2E hoofdzaak" under "Gerelateerde zaken"', null, { page, testData }); 
    await And('I cannot close the zaak "E2E hoofdzaak" while "E2E deelzaak" is open', null, { page, testData }); 
    await When('I close the zaak "E2E deelzaak" with a resultaat', null, { page, testData }); 
    await Then('I can close the zaak "E2E hoofdzaak" with a resultaat', null, { page, testData }); 
  });

});

// == technical section ==

test.use({
  $test: [({}, use) => use(test), { scope: 'test', box: true }],
  $uri: [({}, use) => use('bdd/@zaak/@cmmn/zaken-koppelen.feature'), { scope: 'test', box: true }],
  $bddFileData: [({}, use) => use(bddFileData), { scope: "test", box: true }],
});

const bddFileData = [ // bdd-data-start
  {"pwTestLine":11,"pickleLine":15,"tags":["@behandelaar","@zaak","@cmmn"],"steps":[{"pwStepLine":7,"gherkinStepLine":12,"keywordType":"Context","textWithKeyword":"Given a zaak \"E2E hoofdzaak\" in behandeling","isBg":true,"stepMatchArguments":[{"group":{"start":7,"value":"\"E2E hoofdzaak\"","children":[{"start":8,"value":"E2E hoofdzaak","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":8,"gherkinStepLine":13,"keywordType":"Context","textWithKeyword":"And a zaak \"E2E deelzaak\" in behandeling, of a zaaktype that the hoofdzaak allows as deelzaak","isBg":true,"stepMatchArguments":[{"group":{"start":7,"value":"\"E2E deelzaak\"","children":[{"start":8,"value":"E2E deelzaak","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":12,"gherkinStepLine":16,"keywordType":"Action","textWithKeyword":"When I open the zaak \"E2E hoofdzaak\"","stepMatchArguments":[{"group":{"start":16,"value":"\"E2E hoofdzaak\"","children":[{"start":17,"value":"E2E hoofdzaak","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":13,"gherkinStepLine":17,"keywordType":"Action","textWithKeyword":"And I link the zaak \"E2E deelzaak\" as deelzaak","stepMatchArguments":[{"group":{"start":16,"value":"\"E2E deelzaak\"","children":[{"start":17,"value":"E2E deelzaak","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":14,"gherkinStepLine":18,"keywordType":"Outcome","textWithKeyword":"Then the zaak \"E2E hoofdzaak\" shows \"E2E deelzaak\" under \"Gerelateerde zaken\"","stepMatchArguments":[{"group":{"start":9,"value":"\"E2E hoofdzaak\"","children":[{"start":10,"value":"E2E hoofdzaak","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"},{"group":{"start":31,"value":"\"E2E deelzaak\"","children":[{"start":32,"value":"E2E deelzaak","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"},{"group":{"start":52,"value":"\"Gerelateerde zaken\"","children":[{"start":53,"value":"Gerelateerde zaken","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":15,"gherkinStepLine":19,"keywordType":"Outcome","textWithKeyword":"And the zaak \"E2E deelzaak\" shows \"E2E hoofdzaak\" under \"Gerelateerde zaken\"","stepMatchArguments":[{"group":{"start":9,"value":"\"E2E deelzaak\"","children":[{"start":10,"value":"E2E deelzaak","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"},{"group":{"start":30,"value":"\"E2E hoofdzaak\"","children":[{"start":31,"value":"E2E hoofdzaak","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"},{"group":{"start":52,"value":"\"Gerelateerde zaken\"","children":[{"start":53,"value":"Gerelateerde zaken","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":16,"gherkinStepLine":20,"keywordType":"Outcome","textWithKeyword":"And I cannot close the zaak \"E2E hoofdzaak\" while \"E2E deelzaak\" is open","stepMatchArguments":[{"group":{"start":24,"value":"\"E2E hoofdzaak\"","children":[{"start":25,"value":"E2E hoofdzaak","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"},{"group":{"start":46,"value":"\"E2E deelzaak\"","children":[{"start":47,"value":"E2E deelzaak","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":17,"gherkinStepLine":21,"keywordType":"Action","textWithKeyword":"When I close the zaak \"E2E deelzaak\" with a resultaat","stepMatchArguments":[{"group":{"start":17,"value":"\"E2E deelzaak\"","children":[{"start":18,"value":"E2E deelzaak","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":18,"gherkinStepLine":22,"keywordType":"Outcome","textWithKeyword":"Then I can close the zaak \"E2E hoofdzaak\" with a resultaat","stepMatchArguments":[{"group":{"start":21,"value":"\"E2E hoofdzaak\"","children":[{"start":22,"value":"E2E hoofdzaak","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]}]},
]; // bdd-data-end