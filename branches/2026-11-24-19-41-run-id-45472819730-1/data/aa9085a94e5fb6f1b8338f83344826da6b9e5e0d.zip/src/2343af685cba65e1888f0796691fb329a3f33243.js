// Generated from: bdd/@zaak/@cmmn/zaak-aanmaken.feature
import { test } from "../../../bdd/fixtures.ts";

test.describe('Zaak aanmaken', () => {

  test.beforeEach('Background', async ({ Given, testData }, testInfo) => { if (testInfo.error) return;
    await Given('the zaaktype "Test zaaktype 2" is set up and assigns new zaken to groep "Test group behandelaars domein test 1"', null, { testData }); 
  });
  
  test.describe('A behandelaar creates a zaak with a <initiator> as initiator', () => {

    test('A behandelaar creates a zaak with a persoon as initiator', { tag: ['@behandelaar', '@zaak', '@cmmn'] }, async ({ When, Then, And, page, testData }) => { 
      await When('I open the form to create a zaak', null, { page }); 
      await And('I choose the zaaktype "Test zaaktype 2"', null, { page }); 
      await And('I search the persoon with BSN "999992958" and select "Anita van Buren" as initiator', null, { page }); 
      await And('I search an address in the BAG and add it as BAG object', null, { page }); 
      await And('I choose the communicatiekanaal "E-mail"', null, { page }); 
      await And('I enter the omschrijving "E2E zaak met persoon"', null, { page, testData }); 
      await And('I create the zaak', null, { page, testData }); 
      await Then('the zaak opens with status "Intake"', null, { page, testData }); 
      await And('the zaak shows "Anita van Buren" as initiator', null, { page }); 
      await And('the zaak shows that address as BAG object', null, { page }); 
      await And('the zaak is assigned to groep "Test group behandelaars domein test 1"', null, { page }); 
      await And('the zaak shows that no ontvangstbevestiging is sent', null, { page }); 
      await And('the zaak appears in the zaken werkvoorraad', null, { page, testData }); 
    });

    test('A behandelaar creates a zaak with a bedrijf as initiator', { tag: ['@behandelaar', '@zaak', '@cmmn'] }, async ({ When, Then, And, page, testData }) => { 
      await When('I open the form to create a zaak', null, { page }); 
      await And('I choose the zaaktype "Test zaaktype 2"', null, { page }); 
      await And('I search the bedrijf with KvK "12345678" and select "fakeNaam1" as initiator', null, { page }); 
      await And('I search an address in the BAG and add it as BAG object', null, { page }); 
      await And('I choose the communicatiekanaal "E-mail"', null, { page }); 
      await And('I enter the omschrijving "E2E zaak met bedrijf"', null, { page, testData }); 
      await And('I create the zaak', null, { page, testData }); 
      await Then('the zaak opens with status "Intake"', null, { page, testData }); 
      await And('the zaak shows "fakeNaam1" as initiator', null, { page }); 
      await And('the zaak shows that address as BAG object', null, { page }); 
      await And('the zaak is assigned to groep "Test group behandelaars domein test 1"', null, { page }); 
      await And('the zaak shows that no ontvangstbevestiging is sent', null, { page }); 
      await And('the zaak appears in the zaken werkvoorraad', null, { page, testData }); 
    });

  });

});

// == technical section ==

test.use({
  $test: [({}, use) => use(test), { scope: 'test', box: true }],
  $uri: [({}, use) => use('bdd/@zaak/@cmmn/zaak-aanmaken.feature'), { scope: 'test', box: true }],
  $bddFileData: [({}, use) => use(bddFileData), { scope: "test", box: true }],
});

const bddFileData = [ // bdd-data-start
  {"pwTestLine":12,"pickleLine":31,"tags":["@behandelaar","@zaak","@cmmn"],"steps":[{"pwStepLine":7,"gherkinStepLine":12,"keywordType":"Context","textWithKeyword":"Given the zaaktype \"Test zaaktype 2\" is set up and assigns new zaken to groep \"Test group behandelaars domein test 1\"","isBg":true,"stepMatchArguments":[{"group":{"start":13,"value":"\"Test zaaktype 2\"","children":[{"start":14,"value":"Test zaaktype 2"}]},"parameterTypeName":"seeded"},{"group":{"start":72,"value":"\"Test group behandelaars domein test 1\"","children":[{"start":73,"value":"Test group behandelaars domein test 1"}]},"parameterTypeName":"seeded"}]},{"pwStepLine":13,"gherkinStepLine":15,"keywordType":"Action","textWithKeyword":"When I open the form to create a zaak","stepMatchArguments":[]},{"pwStepLine":14,"gherkinStepLine":16,"keywordType":"Action","textWithKeyword":"And I choose the zaaktype \"Test zaaktype 2\"","stepMatchArguments":[{"group":{"start":22,"value":"\"Test zaaktype 2\"","children":[{"start":23,"value":"Test zaaktype 2"}]},"parameterTypeName":"seeded"}]},{"pwStepLine":15,"gherkinStepLine":17,"keywordType":"Action","textWithKeyword":"And I search the persoon with BSN \"999992958\" and select \"Anita van Buren\" as initiator","stepMatchArguments":[{"group":{"start":30,"value":"\"999992958\"","children":[{"start":31,"value":"999992958","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"},{"group":{"start":53,"value":"\"Anita van Buren\"","children":[{"start":54,"value":"Anita van Buren","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":16,"gherkinStepLine":18,"keywordType":"Action","textWithKeyword":"And I search an address in the BAG and add it as BAG object","stepMatchArguments":[]},{"pwStepLine":17,"gherkinStepLine":19,"keywordType":"Action","textWithKeyword":"And I choose the communicatiekanaal \"E-mail\"","stepMatchArguments":[{"group":{"start":32,"value":"\"E-mail\"","children":[{"start":33,"value":"E-mail","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":18,"gherkinStepLine":20,"keywordType":"Action","textWithKeyword":"And I enter the omschrijving \"E2E zaak met persoon\"","stepMatchArguments":[{"group":{"start":25,"value":"\"E2E zaak met persoon\"","children":[{"start":26,"value":"E2E zaak met persoon","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":19,"gherkinStepLine":21,"keywordType":"Action","textWithKeyword":"And I create the zaak","stepMatchArguments":[]},{"pwStepLine":20,"gherkinStepLine":22,"keywordType":"Outcome","textWithKeyword":"Then the zaak opens with status \"Intake\"","stepMatchArguments":[{"group":{"start":27,"value":"\"Intake\"","children":[{"start":28,"value":"Intake","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":21,"gherkinStepLine":23,"keywordType":"Outcome","textWithKeyword":"And the zaak shows \"Anita van Buren\" as initiator","stepMatchArguments":[{"group":{"start":15,"value":"\"Anita van Buren\"","children":[{"start":16,"value":"Anita van Buren"}]},"parameterTypeName":"seeded"}]},{"pwStepLine":22,"gherkinStepLine":24,"keywordType":"Outcome","textWithKeyword":"And the zaak shows that address as BAG object","stepMatchArguments":[]},{"pwStepLine":23,"gherkinStepLine":25,"keywordType":"Outcome","textWithKeyword":"And the zaak is assigned to groep \"Test group behandelaars domein test 1\"","stepMatchArguments":[{"group":{"start":30,"value":"\"Test group behandelaars domein test 1\"","children":[{"start":31,"value":"Test group behandelaars domein test 1"}]},"parameterTypeName":"seeded"}]},{"pwStepLine":24,"gherkinStepLine":26,"keywordType":"Outcome","textWithKeyword":"And the zaak shows that no ontvangstbevestiging is sent","stepMatchArguments":[]},{"pwStepLine":25,"gherkinStepLine":27,"keywordType":"Outcome","textWithKeyword":"And the zaak appears in the zaken werkvoorraad","stepMatchArguments":[]}]},
  {"pwTestLine":28,"pickleLine":32,"tags":["@behandelaar","@zaak","@cmmn"],"steps":[{"pwStepLine":7,"gherkinStepLine":12,"keywordType":"Context","textWithKeyword":"Given the zaaktype \"Test zaaktype 2\" is set up and assigns new zaken to groep \"Test group behandelaars domein test 1\"","isBg":true,"stepMatchArguments":[{"group":{"start":13,"value":"\"Test zaaktype 2\"","children":[{"start":14,"value":"Test zaaktype 2"}]},"parameterTypeName":"seeded"},{"group":{"start":72,"value":"\"Test group behandelaars domein test 1\"","children":[{"start":73,"value":"Test group behandelaars domein test 1"}]},"parameterTypeName":"seeded"}]},{"pwStepLine":29,"gherkinStepLine":15,"keywordType":"Action","textWithKeyword":"When I open the form to create a zaak","stepMatchArguments":[]},{"pwStepLine":30,"gherkinStepLine":16,"keywordType":"Action","textWithKeyword":"And I choose the zaaktype \"Test zaaktype 2\"","stepMatchArguments":[{"group":{"start":22,"value":"\"Test zaaktype 2\"","children":[{"start":23,"value":"Test zaaktype 2"}]},"parameterTypeName":"seeded"}]},{"pwStepLine":31,"gherkinStepLine":17,"keywordType":"Action","textWithKeyword":"And I search the bedrijf with KvK \"12345678\" and select \"fakeNaam1\" as initiator","stepMatchArguments":[{"group":{"start":30,"value":"\"12345678\"","children":[{"start":31,"value":"12345678"}]},"parameterTypeName":"seeded"},{"group":{"start":52,"value":"\"fakeNaam1\"","children":[{"start":53,"value":"fakeNaam1"}]},"parameterTypeName":"seeded"}]},{"pwStepLine":32,"gherkinStepLine":18,"keywordType":"Action","textWithKeyword":"And I search an address in the BAG and add it as BAG object","stepMatchArguments":[]},{"pwStepLine":33,"gherkinStepLine":19,"keywordType":"Action","textWithKeyword":"And I choose the communicatiekanaal \"E-mail\"","stepMatchArguments":[{"group":{"start":32,"value":"\"E-mail\"","children":[{"start":33,"value":"E-mail","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":34,"gherkinStepLine":20,"keywordType":"Action","textWithKeyword":"And I enter the omschrijving \"E2E zaak met bedrijf\"","stepMatchArguments":[{"group":{"start":25,"value":"\"E2E zaak met bedrijf\"","children":[{"start":26,"value":"E2E zaak met bedrijf","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":35,"gherkinStepLine":21,"keywordType":"Action","textWithKeyword":"And I create the zaak","stepMatchArguments":[]},{"pwStepLine":36,"gherkinStepLine":22,"keywordType":"Outcome","textWithKeyword":"Then the zaak opens with status \"Intake\"","stepMatchArguments":[{"group":{"start":27,"value":"\"Intake\"","children":[{"start":28,"value":"Intake","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":37,"gherkinStepLine":23,"keywordType":"Outcome","textWithKeyword":"And the zaak shows \"fakeNaam1\" as initiator","stepMatchArguments":[{"group":{"start":15,"value":"\"fakeNaam1\"","children":[{"start":16,"value":"fakeNaam1"}]},"parameterTypeName":"seeded"}]},{"pwStepLine":38,"gherkinStepLine":24,"keywordType":"Outcome","textWithKeyword":"And the zaak shows that address as BAG object","stepMatchArguments":[]},{"pwStepLine":39,"gherkinStepLine":25,"keywordType":"Outcome","textWithKeyword":"And the zaak is assigned to groep \"Test group behandelaars domein test 1\"","stepMatchArguments":[{"group":{"start":30,"value":"\"Test group behandelaars domein test 1\"","children":[{"start":31,"value":"Test group behandelaars domein test 1"}]},"parameterTypeName":"seeded"}]},{"pwStepLine":40,"gherkinStepLine":26,"keywordType":"Outcome","textWithKeyword":"And the zaak shows that no ontvangstbevestiging is sent","stepMatchArguments":[]},{"pwStepLine":41,"gherkinStepLine":27,"keywordType":"Outcome","textWithKeyword":"And the zaak appears in the zaken werkvoorraad","stepMatchArguments":[]}]},
]; // bdd-data-end