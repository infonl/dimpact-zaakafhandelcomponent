// Generated from: bdd/@zaak/@cmmn/zaakafhandelparameters.feature
import { test } from "../../../bdd/fixtures.ts";

test.describe('Zaakafhandelparameters', () => {

  test.beforeEach('Background', async ({ Given, testData }, testInfo) => { if (testInfo.error) return;
    await Given('the zaaktype "Test zaaktype 4" is set up and assigns new zaken to groep "Test group behandelaars domein test 1"', null, { testData }); 
  });
  
  test('A changed default groep applies to new zaken', { tag: ['@beheerder', '@zaak', '@cmmn'] }, async ({ When, Then, And, page, testData }) => { 
    await When('I open the zaakafhandelparameters of "Test zaaktype 4"', null, { page }); 
    await And('I change the default groep to "Test group behandelaars with a very long group name"', null, { page }); 
    await And('I save the zaakafhandelparameters', null, { page }); 
    await Then('I see the message "De zaakafhandelparameters zijn opgeslagen"', null, { page }); 
    await When('I open the zaakafhandelparameters of "Test zaaktype 4"', null, { page }); 
    await Then('the default groep is "Test group behandelaars with a very long group name"', null, { page }); 
    await When('I open the form to create a zaak', null, { page }); 
    await And('I choose the zaaktype "Test zaaktype 4"', null, { page }); 
    await And('I choose the communicatiekanaal "E-mail"', null, { page }); 
    await And('I enter the omschrijving "E2E zaak na gewijzigde parameters"', null, { page, testData }); 
    await And('I create the zaak', null, { page, testData }); 
    await Then('the zaak is assigned to groep "Test group behandelaars with a very long group name"', null, { page }); 
  });

});

// == technical section ==

test.use({
  $test: [({}, use) => use(test), { scope: 'test', box: true }],
  $uri: [({}, use) => use('bdd/@zaak/@cmmn/zaakafhandelparameters.feature'), { scope: 'test', box: true }],
  $bddFileData: [({}, use) => use(bddFileData), { scope: "test", box: true }],
  page: async ({ page, $prompt }, use) => {
    $prompt.setPage(page);
    await use(page);
  },
});

const bddFileData = [ // bdd-data-start
  {"pwTestLine":10,"pickleLine":15,"tags":["@beheerder","@zaak","@cmmn"],"steps":[{"pwStepLine":7,"gherkinStepLine":13,"keywordType":"Context","textWithKeyword":"Given the zaaktype \"Test zaaktype 4\" is set up and assigns new zaken to groep \"Test group behandelaars domein test 1\"","isBg":true,"stepMatchArguments":[{"group":{"start":13,"value":"\"Test zaaktype 4\"","children":[{"start":14,"value":"Test zaaktype 4"}]},"parameterTypeName":"seeded"},{"group":{"start":72,"value":"\"Test group behandelaars domein test 1\"","children":[{"start":73,"value":"Test group behandelaars domein test 1"}]},"parameterTypeName":"seeded"}]},{"pwStepLine":11,"gherkinStepLine":16,"keywordType":"Action","textWithKeyword":"When I open the zaakafhandelparameters of \"Test zaaktype 4\"","stepMatchArguments":[{"group":{"start":37,"value":"\"Test zaaktype 4\"","children":[{"start":38,"value":"Test zaaktype 4"}]},"parameterTypeName":"seeded"}]},{"pwStepLine":12,"gherkinStepLine":17,"keywordType":"Action","textWithKeyword":"And I change the default groep to \"Test group behandelaars with a very long group name\"","stepMatchArguments":[{"group":{"start":30,"value":"\"Test group behandelaars with a very long group name\"","children":[{"start":31,"value":"Test group behandelaars with a very long group name"}]},"parameterTypeName":"seeded"}]},{"pwStepLine":13,"gherkinStepLine":18,"keywordType":"Action","textWithKeyword":"And I save the zaakafhandelparameters","stepMatchArguments":[]},{"pwStepLine":14,"gherkinStepLine":19,"keywordType":"Outcome","textWithKeyword":"Then I see the message \"De zaakafhandelparameters zijn opgeslagen\"","stepMatchArguments":[{"group":{"start":18,"value":"\"De zaakafhandelparameters zijn opgeslagen\"","children":[{"start":19,"value":"De zaakafhandelparameters zijn opgeslagen","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":15,"gherkinStepLine":20,"keywordType":"Action","textWithKeyword":"When I open the zaakafhandelparameters of \"Test zaaktype 4\"","stepMatchArguments":[{"group":{"start":37,"value":"\"Test zaaktype 4\"","children":[{"start":38,"value":"Test zaaktype 4"}]},"parameterTypeName":"seeded"}]},{"pwStepLine":16,"gherkinStepLine":21,"keywordType":"Outcome","textWithKeyword":"Then the default groep is \"Test group behandelaars with a very long group name\"","stepMatchArguments":[{"group":{"start":21,"value":"\"Test group behandelaars with a very long group name\"","children":[{"start":22,"value":"Test group behandelaars with a very long group name"}]},"parameterTypeName":"seeded"}]},{"pwStepLine":17,"gherkinStepLine":22,"keywordType":"Action","textWithKeyword":"When I open the form to create a zaak","stepMatchArguments":[]},{"pwStepLine":18,"gherkinStepLine":23,"keywordType":"Action","textWithKeyword":"And I choose the zaaktype \"Test zaaktype 4\"","stepMatchArguments":[{"group":{"start":22,"value":"\"Test zaaktype 4\"","children":[{"start":23,"value":"Test zaaktype 4"}]},"parameterTypeName":"seeded"}]},{"pwStepLine":19,"gherkinStepLine":24,"keywordType":"Action","textWithKeyword":"And I choose the communicatiekanaal \"E-mail\"","stepMatchArguments":[{"group":{"start":32,"value":"\"E-mail\"","children":[{"start":33,"value":"E-mail","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":20,"gherkinStepLine":25,"keywordType":"Action","textWithKeyword":"And I enter the omschrijving \"E2E zaak na gewijzigde parameters\"","stepMatchArguments":[{"group":{"start":25,"value":"\"E2E zaak na gewijzigde parameters\"","children":[{"start":26,"value":"E2E zaak na gewijzigde parameters","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":21,"gherkinStepLine":26,"keywordType":"Action","textWithKeyword":"And I create the zaak","stepMatchArguments":[]},{"pwStepLine":22,"gherkinStepLine":27,"keywordType":"Outcome","textWithKeyword":"Then the zaak is assigned to groep \"Test group behandelaars with a very long group name\"","stepMatchArguments":[{"group":{"start":30,"value":"\"Test group behandelaars with a very long group name\"","children":[{"start":31,"value":"Test group behandelaars with a very long group name"}]},"parameterTypeName":"seeded"}]}]},
]; // bdd-data-end