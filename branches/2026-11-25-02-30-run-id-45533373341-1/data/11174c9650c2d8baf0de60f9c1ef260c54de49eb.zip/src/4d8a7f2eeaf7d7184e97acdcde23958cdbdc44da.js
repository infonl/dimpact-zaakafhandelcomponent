// Generated from: bdd/@zaak/@cmmn/intake.feature
import { test } from "../../../bdd/fixtures.ts";

test.describe('Intake', () => {

  test.beforeEach('Background', async ({ Given, testData }, testInfo) => { if (testInfo.error) return;
    await Given('a zaak in intake with a person as initiator', null, { testData }); 
  });
  
  test('A zaak waits for aanvullende informatie, then continues and is extended', { tag: ['@behandelaar', '@zaak', '@cmmn'] }, async ({ When, Then, And, accountOfRole, page, testData }) => { 
    await When('I open the zaak', null, { page, testData }); 
    await And('I request aanvullende informatie from the initiator', null, { page, testData }); 
    await And('I suspend the zaak for 14 days with the reason "Wacht op informatie"', null, { page }); 
    await Then('the status is "Wacht op aanvullende informatie"', null, { page }); 
    await And('the zaak shows the indicatie "opgeschort"', null, { page }); 
    await And('the uiterste einddatum moves 14 days later', null, { page }); 
    await When('I complete the aanvullende informatie task', null, { accountOfRole, page, testData }); 
    await And('I resume the zaak with the reason "Informatie ontvangen"', null, { page }); 
    await Then('the status is "Intake"', null, { page }); 
    await And('the zaak no longer shows the indicatie "opgeschort"', null, { page }); 
    await When('I finish the intake as ontvankelijk', null, { page }); 
    await Then('the status is "In behandeling"', null, { page }); 
    await When('I extend the zaak by 10 days with the reason "Extra onderzoek nodig"', null, { page }); 
    await Then('the zaak shows the indicatie "verlengd"', null, { page }); 
    await And('the uiterste einddatum moves 10 days later', null, { page }); 
    await And('the historie lists the request, the suspension, the resumption, the intake and the extension', null, { page }); 
  });

});

// == technical section ==

test.use({
  $test: [({}, use) => use(test), { scope: 'test', box: true }],
  $uri: [({}, use) => use('bdd/@zaak/@cmmn/intake.feature'), { scope: 'test', box: true }],
  $bddFileData: [({}, use) => use(bddFileData), { scope: "test", box: true }],
  page: async ({ page, $prompt }, use) => {
    $prompt.setPage(page);
    await use(page);
  },
});

const bddFileData = [ // bdd-data-start
  {"pwTestLine":10,"pickleLine":14,"tags":["@behandelaar","@zaak","@cmmn"],"steps":[{"pwStepLine":7,"gherkinStepLine":12,"keywordType":"Context","textWithKeyword":"Given a zaak in intake with a person as initiator","isBg":true,"stepMatchArguments":[]},{"pwStepLine":11,"gherkinStepLine":15,"keywordType":"Action","textWithKeyword":"When I open the zaak","stepMatchArguments":[]},{"pwStepLine":12,"gherkinStepLine":16,"keywordType":"Action","textWithKeyword":"And I request aanvullende informatie from the initiator","stepMatchArguments":[]},{"pwStepLine":13,"gherkinStepLine":17,"keywordType":"Action","textWithKeyword":"And I suspend the zaak for 14 days with the reason \"Wacht op informatie\"","stepMatchArguments":[{"group":{"start":23,"value":"14"},"parameterTypeName":"int"},{"group":{"start":47,"value":"\"Wacht op informatie\"","children":[{"start":48,"value":"Wacht op informatie","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":14,"gherkinStepLine":18,"keywordType":"Outcome","textWithKeyword":"Then the status is \"Wacht op aanvullende informatie\"","stepMatchArguments":[{"group":{"start":14,"value":"\"Wacht op aanvullende informatie\"","children":[{"start":15,"value":"Wacht op aanvullende informatie","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":15,"gherkinStepLine":19,"keywordType":"Outcome","textWithKeyword":"And the zaak shows the indicatie \"opgeschort\"","stepMatchArguments":[{"group":{"start":29,"value":"\"opgeschort\"","children":[{"start":30,"value":"opgeschort","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":16,"gherkinStepLine":20,"keywordType":"Outcome","textWithKeyword":"And the uiterste einddatum moves 14 days later","stepMatchArguments":[{"group":{"start":29,"value":"14"},"parameterTypeName":"int"}]},{"pwStepLine":17,"gherkinStepLine":21,"keywordType":"Action","textWithKeyword":"When I complete the aanvullende informatie task","stepMatchArguments":[]},{"pwStepLine":18,"gherkinStepLine":22,"keywordType":"Action","textWithKeyword":"And I resume the zaak with the reason \"Informatie ontvangen\"","stepMatchArguments":[{"group":{"start":34,"value":"\"Informatie ontvangen\"","children":[{"start":35,"value":"Informatie ontvangen","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":19,"gherkinStepLine":23,"keywordType":"Outcome","textWithKeyword":"Then the status is \"Intake\"","stepMatchArguments":[{"group":{"start":14,"value":"\"Intake\"","children":[{"start":15,"value":"Intake","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":20,"gherkinStepLine":24,"keywordType":"Outcome","textWithKeyword":"And the zaak no longer shows the indicatie \"opgeschort\"","stepMatchArguments":[{"group":{"start":39,"value":"\"opgeschort\"","children":[{"start":40,"value":"opgeschort","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":21,"gherkinStepLine":25,"keywordType":"Action","textWithKeyword":"When I finish the intake as ontvankelijk","stepMatchArguments":[]},{"pwStepLine":22,"gherkinStepLine":26,"keywordType":"Outcome","textWithKeyword":"Then the status is \"In behandeling\"","stepMatchArguments":[{"group":{"start":14,"value":"\"In behandeling\"","children":[{"start":15,"value":"In behandeling","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":23,"gherkinStepLine":27,"keywordType":"Action","textWithKeyword":"When I extend the zaak by 10 days with the reason \"Extra onderzoek nodig\"","stepMatchArguments":[{"group":{"start":21,"value":"10"},"parameterTypeName":"int"},{"group":{"start":45,"value":"\"Extra onderzoek nodig\"","children":[{"start":46,"value":"Extra onderzoek nodig","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":24,"gherkinStepLine":28,"keywordType":"Outcome","textWithKeyword":"Then the zaak shows the indicatie \"verlengd\"","stepMatchArguments":[{"group":{"start":29,"value":"\"verlengd\"","children":[{"start":30,"value":"verlengd","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":25,"gherkinStepLine":29,"keywordType":"Outcome","textWithKeyword":"And the uiterste einddatum moves 10 days later","stepMatchArguments":[{"group":{"start":29,"value":"10"},"parameterTypeName":"int"}]},{"pwStepLine":26,"gherkinStepLine":30,"keywordType":"Outcome","textWithKeyword":"And the historie lists the request, the suspension, the resumption, the intake and the extension","stepMatchArguments":[]}]},
]; // bdd-data-end