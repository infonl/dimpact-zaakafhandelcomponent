// Generated from: bdd/@zaak/@cmmn/smartdocuments.feature
import { test } from "../../../bdd/fixtures.ts";

test.describe('SmartDocuments', () => {

  test.beforeEach('Background', async ({ Given, testData }, testInfo) => { if (testInfo.error) return;
    await Given('a zaak in intake', null, { testData }); 
  });
  
  test('A behandelaar creates a document with the SmartDocuments wizard', { tag: ['@behandelaar', '@live-env-only', '@zaak', '@cmmn'] }, async ({ When, Then, And, page, testData }) => { 
    await When('I open the zaak', null, { page, testData }); 
    await And('I start the SmartDocuments wizard for the document "E2E SmartDocuments"', null, { page, testData }); 
    await And('I complete the SmartDocuments wizard', null, { page }); 
    await Then('the zaak lists the document "E2E SmartDocuments"', null, { page, testData }); 
    await And('the document "E2E SmartDocuments" shows the titel, the beschrijving and the auteur that I entered', null, { page, testData }); 
  });

});

// == technical section ==

test.use({
  $test: [({}, use) => use(test), { scope: 'test', box: true }],
  $uri: [({}, use) => use('bdd/@zaak/@cmmn/smartdocuments.feature'), { scope: 'test', box: true }],
  $bddFileData: [({}, use) => use(bddFileData), { scope: "test", box: true }],
  page: async ({ page, $prompt }, use) => {
    $prompt.setPage(page);
    await use(page);
  },
});

const bddFileData = [ // bdd-data-start
  {"pwTestLine":10,"pickleLine":14,"tags":["@behandelaar","@live-env-only","@zaak","@cmmn"],"steps":[{"pwStepLine":7,"gherkinStepLine":12,"keywordType":"Context","textWithKeyword":"Given a zaak in intake","isBg":true,"stepMatchArguments":[]},{"pwStepLine":11,"gherkinStepLine":15,"keywordType":"Action","textWithKeyword":"When I open the zaak","stepMatchArguments":[]},{"pwStepLine":12,"gherkinStepLine":16,"keywordType":"Action","textWithKeyword":"And I start the SmartDocuments wizard for the document \"E2E SmartDocuments\"","stepMatchArguments":[{"group":{"start":51,"value":"\"E2E SmartDocuments\"","children":[{"start":52,"value":"E2E SmartDocuments","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":13,"gherkinStepLine":17,"keywordType":"Action","textWithKeyword":"And I complete the SmartDocuments wizard","stepMatchArguments":[]},{"pwStepLine":14,"gherkinStepLine":18,"keywordType":"Outcome","textWithKeyword":"Then the zaak lists the document \"E2E SmartDocuments\"","stepMatchArguments":[{"group":{"start":28,"value":"\"E2E SmartDocuments\"","children":[{"start":29,"value":"E2E SmartDocuments","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":15,"gherkinStepLine":19,"keywordType":"Outcome","textWithKeyword":"And the document \"E2E SmartDocuments\" shows the titel, the beschrijving and the auteur that I entered","stepMatchArguments":[{"group":{"start":13,"value":"\"E2E SmartDocuments\"","children":[{"start":14,"value":"E2E SmartDocuments","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]}]},
]; // bdd-data-end