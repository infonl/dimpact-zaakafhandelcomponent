// Generated from: bdd/@zaak/@bpmn/bpmn-proces.feature
import { test } from "../../../bdd/fixtures.ts";

test.describe('BPMN-proces', () => {

  test.beforeEach('Background', async ({ Given, And, testData }, testInfo) => { if (testInfo.error) return;
    await Given('the E2E process and its forms are deployed', null, { testData }); 
    await And('the zaaktype "BPMN test zaaktype 5" uses the E2E process and assigns new zaken to groep "Test group behandelaars domein test 1"', null, { testData }); 
  });
  
  test('A behandelaar handles a BPMN zaak from start to end', { tag: ['@behandelaar', '@zaak', '@bpmn'] }, async ({ When, Then, And, accountOfRole, apiAs, page, testData }) => { 
    await When('I open the form to create a zaak', null, { page }); 
    await And('I choose the zaaktype "BPMN test zaaktype 5"', null, { page }); 
    await And('I choose the communicatiekanaal "E-mail"', null, { page }); 
    await And('I enter the omschrijving "E2E BPMN-zaak"', null, { page, testData }); 
    await And('I create the zaak', null, { page, testData }); 
    await Then('the zaak shows the task "MultipleFormItems"', null, { page }); 
    await When('I open the task "MultipleFormItems" of the zaak', null, { page, testData }); 
    await And('I fill in all required fields of the form, with the resultaat "Verleend" and the status "Afgerond"', null, { accountOfRole, page, testData }); 
    await And('I submit the form', null, { page }); 
    await Then('the zaak lists the task "MultipleFormItems" as afgerond', null, { page, testData }); 
    await And('the task "MultipleFormItemsSummary" starts for groep "Test group behandelaars domein test 1"', null, { page }); 
    await When('I open the task "MultipleFormItemsSummary" of the zaak', null, { page, testData }); 
    await Then('the form shows the values that I entered, with the resultaat "Verleend" and the status "Afgerond"', null, { accountOfRole, page, testData }); 
    await When('I confirm the summary', null, { page, testData }); 
    await Then('the status is "Afgerond"', null, { page }); 
    await And('the zaak has the resultaat "Verleend"', null, { apiAs, testData }); 
  });

});

// == technical section ==

test.use({
  $test: [({}, use) => use(test), { scope: 'test', box: true }],
  $uri: [({}, use) => use('bdd/@zaak/@bpmn/bpmn-proces.feature'), { scope: 'test', box: true }],
  $bddFileData: [({}, use) => use(bddFileData), { scope: "test", box: true }],
  page: async ({ page, $prompt }, use) => {
    $prompt.setPage(page);
    await use(page);
  },
});

const bddFileData = [ // bdd-data-start
  {"pwTestLine":11,"pickleLine":15,"tags":["@behandelaar","@zaak","@bpmn"],"steps":[{"pwStepLine":7,"gherkinStepLine":12,"keywordType":"Context","textWithKeyword":"Given the E2E process and its forms are deployed","isBg":true,"stepMatchArguments":[]},{"pwStepLine":8,"gherkinStepLine":13,"keywordType":"Context","textWithKeyword":"And the zaaktype \"BPMN test zaaktype 5\" uses the E2E process and assigns new zaken to groep \"Test group behandelaars domein test 1\"","isBg":true,"stepMatchArguments":[{"group":{"start":13,"value":"\"BPMN test zaaktype 5\"","children":[{"start":14,"value":"BPMN test zaaktype 5"}]},"parameterTypeName":"seeded"},{"group":{"start":88,"value":"\"Test group behandelaars domein test 1\"","children":[{"start":89,"value":"Test group behandelaars domein test 1"}]},"parameterTypeName":"seeded"}]},{"pwStepLine":12,"gherkinStepLine":16,"keywordType":"Action","textWithKeyword":"When I open the form to create a zaak","stepMatchArguments":[]},{"pwStepLine":13,"gherkinStepLine":17,"keywordType":"Action","textWithKeyword":"And I choose the zaaktype \"BPMN test zaaktype 5\"","stepMatchArguments":[{"group":{"start":22,"value":"\"BPMN test zaaktype 5\"","children":[{"start":23,"value":"BPMN test zaaktype 5"}]},"parameterTypeName":"seeded"}]},{"pwStepLine":14,"gherkinStepLine":18,"keywordType":"Action","textWithKeyword":"And I choose the communicatiekanaal \"E-mail\"","stepMatchArguments":[{"group":{"start":32,"value":"\"E-mail\"","children":[{"start":33,"value":"E-mail","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":15,"gherkinStepLine":19,"keywordType":"Action","textWithKeyword":"And I enter the omschrijving \"E2E BPMN-zaak\"","stepMatchArguments":[{"group":{"start":25,"value":"\"E2E BPMN-zaak\"","children":[{"start":26,"value":"E2E BPMN-zaak","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":16,"gherkinStepLine":20,"keywordType":"Action","textWithKeyword":"And I create the zaak","stepMatchArguments":[]},{"pwStepLine":17,"gherkinStepLine":21,"keywordType":"Outcome","textWithKeyword":"Then the zaak shows the task \"MultipleFormItems\"","stepMatchArguments":[{"group":{"start":24,"value":"\"MultipleFormItems\"","children":[{"start":25,"value":"MultipleFormItems","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":18,"gherkinStepLine":22,"keywordType":"Action","textWithKeyword":"When I open the task \"MultipleFormItems\" of the zaak","stepMatchArguments":[{"group":{"start":16,"value":"\"MultipleFormItems\"","children":[{"start":17,"value":"MultipleFormItems","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":19,"gherkinStepLine":23,"keywordType":"Action","textWithKeyword":"And I fill in all required fields of the form, with the resultaat \"Verleend\" and the status \"Afgerond\"","stepMatchArguments":[{"group":{"start":62,"value":"\"Verleend\"","children":[{"start":63,"value":"Verleend","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"},{"group":{"start":88,"value":"\"Afgerond\"","children":[{"start":89,"value":"Afgerond","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":20,"gherkinStepLine":24,"keywordType":"Action","textWithKeyword":"And I submit the form","stepMatchArguments":[]},{"pwStepLine":21,"gherkinStepLine":25,"keywordType":"Outcome","textWithKeyword":"Then the zaak lists the task \"MultipleFormItems\" as afgerond","stepMatchArguments":[{"group":{"start":24,"value":"\"MultipleFormItems\"","children":[{"start":25,"value":"MultipleFormItems","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":22,"gherkinStepLine":26,"keywordType":"Outcome","textWithKeyword":"And the task \"MultipleFormItemsSummary\" starts for groep \"Test group behandelaars domein test 1\"","stepMatchArguments":[{"group":{"start":9,"value":"\"MultipleFormItemsSummary\"","children":[{"start":10,"value":"MultipleFormItemsSummary","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"},{"group":{"start":53,"value":"\"Test group behandelaars domein test 1\"","children":[{"start":54,"value":"Test group behandelaars domein test 1"}]},"parameterTypeName":"seeded"}]},{"pwStepLine":23,"gherkinStepLine":27,"keywordType":"Action","textWithKeyword":"When I open the task \"MultipleFormItemsSummary\" of the zaak","stepMatchArguments":[{"group":{"start":16,"value":"\"MultipleFormItemsSummary\"","children":[{"start":17,"value":"MultipleFormItemsSummary","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":24,"gherkinStepLine":28,"keywordType":"Outcome","textWithKeyword":"Then the form shows the values that I entered, with the resultaat \"Verleend\" and the status \"Afgerond\"","stepMatchArguments":[{"group":{"start":61,"value":"\"Verleend\"","children":[{"start":62,"value":"Verleend","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"},{"group":{"start":87,"value":"\"Afgerond\"","children":[{"start":88,"value":"Afgerond","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":25,"gherkinStepLine":29,"keywordType":"Action","textWithKeyword":"When I confirm the summary","stepMatchArguments":[]},{"pwStepLine":26,"gherkinStepLine":30,"keywordType":"Outcome","textWithKeyword":"Then the status is \"Afgerond\"","stepMatchArguments":[{"group":{"start":14,"value":"\"Afgerond\"","children":[{"start":15,"value":"Afgerond","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":27,"gherkinStepLine":31,"keywordType":"Outcome","textWithKeyword":"And the zaak has the resultaat \"Verleend\"","stepMatchArguments":[{"group":{"start":27,"value":"\"Verleend\"","children":[{"start":28,"value":"Verleend","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]}]},
]; // bdd-data-end