// Generated from: bdd/@zaak/@cmmn/inbox-productaanvragen.feature
import { test } from "../../../bdd/fixtures.ts";

test.describe('Inbox productaanvragen', () => {

  test.beforeEach('Background', async ({ Given, And, request, testData }, testInfo) => { if (testInfo.error) return;
    await Given('the zaaktype "Test zaaktype 2" is set up and assigns new zaken to groep "Test group behandelaars domein test 1"', null, { testData }); 
    await And('a productaanvraag "E2E aanvraag" of a type that ZAC does not know', null, { request, testData }); 
  });
  
  test('A productaanvraag of an unknown type becomes a zaak', { tag: ['@coordinator', '@zaak', '@cmmn'] }, async ({ When, Then, And, page, testData }) => { 
    await When('I open the inbox productaanvragen', null, { page }); 
    await Then('I see the productaanvraag "E2E aanvraag"', null, { page, testData }); 
    await When('I start a zaak from the productaanvraag "E2E aanvraag"', null, { page, testData }); 
    await And('I choose the zaaktype "Test zaaktype 2"', null, { page }); 
    await And('I choose the communicatiekanaal "E-formulier"', null, { page }); 
    await And('I enter the omschrijving "E2E zaak uit productaanvraag"', null, { page, testData }); 
    await And('I create the zaak', null, { page, testData }); 
    await Then('the zaak opens with status "Intake"', null, { page, testData }); 
    await And('the zaak shows the document of the productaanvraag', null, { page, testData }); 
    await And('the inbox productaanvragen no longer shows "E2E aanvraag"', null, { page, testData }); 
  });

});

// == technical section ==

test.use({
  $test: [({}, use) => use(test), { scope: 'test', box: true }],
  $uri: [({}, use) => use('bdd/@zaak/@cmmn/inbox-productaanvragen.feature'), { scope: 'test', box: true }],
  $bddFileData: [({}, use) => use(bddFileData), { scope: "test", box: true }],
  page: async ({ page, $prompt }, use) => {
    $prompt.setPage(page);
    await use(page);
  },
});

const bddFileData = [ // bdd-data-start
  {"pwTestLine":11,"pickleLine":15,"tags":["@coordinator","@zaak","@cmmn"],"steps":[{"pwStepLine":7,"gherkinStepLine":12,"keywordType":"Context","textWithKeyword":"Given the zaaktype \"Test zaaktype 2\" is set up and assigns new zaken to groep \"Test group behandelaars domein test 1\"","isBg":true,"stepMatchArguments":[{"group":{"start":13,"value":"\"Test zaaktype 2\"","children":[{"start":14,"value":"Test zaaktype 2"}]},"parameterTypeName":"seeded"},{"group":{"start":72,"value":"\"Test group behandelaars domein test 1\"","children":[{"start":73,"value":"Test group behandelaars domein test 1"}]},"parameterTypeName":"seeded"}]},{"pwStepLine":8,"gherkinStepLine":13,"keywordType":"Context","textWithKeyword":"And a productaanvraag \"E2E aanvraag\" of a type that ZAC does not know","isBg":true,"stepMatchArguments":[{"group":{"start":18,"value":"\"E2E aanvraag\"","children":[{"start":19,"value":"E2E aanvraag","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":12,"gherkinStepLine":16,"keywordType":"Action","textWithKeyword":"When I open the inbox productaanvragen","stepMatchArguments":[]},{"pwStepLine":13,"gherkinStepLine":17,"keywordType":"Outcome","textWithKeyword":"Then I see the productaanvraag \"E2E aanvraag\"","stepMatchArguments":[{"group":{"start":26,"value":"\"E2E aanvraag\"","children":[{"start":27,"value":"E2E aanvraag","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":14,"gherkinStepLine":18,"keywordType":"Action","textWithKeyword":"When I start a zaak from the productaanvraag \"E2E aanvraag\"","stepMatchArguments":[{"group":{"start":40,"value":"\"E2E aanvraag\"","children":[{"start":41,"value":"E2E aanvraag","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":15,"gherkinStepLine":19,"keywordType":"Action","textWithKeyword":"And I choose the zaaktype \"Test zaaktype 2\"","stepMatchArguments":[{"group":{"start":22,"value":"\"Test zaaktype 2\"","children":[{"start":23,"value":"Test zaaktype 2"}]},"parameterTypeName":"seeded"}]},{"pwStepLine":16,"gherkinStepLine":20,"keywordType":"Action","textWithKeyword":"And I choose the communicatiekanaal \"E-formulier\"","stepMatchArguments":[{"group":{"start":32,"value":"\"E-formulier\"","children":[{"start":33,"value":"E-formulier","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":17,"gherkinStepLine":21,"keywordType":"Action","textWithKeyword":"And I enter the omschrijving \"E2E zaak uit productaanvraag\"","stepMatchArguments":[{"group":{"start":25,"value":"\"E2E zaak uit productaanvraag\"","children":[{"start":26,"value":"E2E zaak uit productaanvraag","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":18,"gherkinStepLine":22,"keywordType":"Action","textWithKeyword":"And I create the zaak","stepMatchArguments":[]},{"pwStepLine":19,"gherkinStepLine":23,"keywordType":"Outcome","textWithKeyword":"Then the zaak opens with status \"Intake\"","stepMatchArguments":[{"group":{"start":27,"value":"\"Intake\"","children":[{"start":28,"value":"Intake","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":20,"gherkinStepLine":24,"keywordType":"Outcome","textWithKeyword":"And the zaak shows the document of the productaanvraag","stepMatchArguments":[]},{"pwStepLine":21,"gherkinStepLine":25,"keywordType":"Outcome","textWithKeyword":"And the inbox productaanvragen no longer shows \"E2E aanvraag\"","stepMatchArguments":[{"group":{"start":43,"value":"\"E2E aanvraag\"","children":[{"start":44,"value":"E2E aanvraag","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]}]},
]; // bdd-data-end