# zaakafhandelcomponent

![Version: 1.0.380](https://img.shields.io/badge/Version-1.0.380-informational?style=flat-square) ![AppVersion: 5.11](https://img.shields.io/badge/AppVersion-5.11-informational?style=flat-square)

A Helm chart for installing Zaakafhandelcomponent

## Maintainers

| Name | Email | Url |
| ---- | ------ | --- |
| Team Dimpact, INFO | <teamdimpact@info.nl> | <https://github.com/infonl/dimpact-zaakafhandelcomponent/discussions> |

## Requirements

| Repository | Name | Version |
|------------|------|---------|
| @opentelemetry | opentelemetry-collector | 0.178.2 |
| @solr | solr-operator | 0.9.1 |

## Usage

Make sure you have helm installed. Add the required repositories as follows:
```
helm repo add opentelemetry https://open-telemetry.github.io/opentelemetry-helm-charts
helm repo add solr https://solr.apache.org/charts
```

If you had already added this repo earlier, run `helm repo update` to retrieve
the latest versions of the packages

Now add the ZAC repo:
```
helm repo add zac https://infonl.github.io/dimpact-zaakafhandelcomponent
```

And install zac:
```
helm install my-release zac/zaakafhandelcomponent
```

## Credentials

Every credential ZAC needs is a chart value, except the Solr credentials that the Solr operator
generates when the chart deploys Solr itself. The chart renders the values into one Kubernetes
`Secret` named after the release, which the ZAC deployment reads through `envFrom`. There is no
external secret store involved, so whoever installs the chart is responsible for supplying the values
from their own secret management (for example a CI secret store) and for keeping them out of any
values file that is committed.

Two services ZAC talks to need credentials on both sides, and the chart keeps the two sides in step:

| Service | User name and password | Where they come from |
|---|---|---|
| Office converter (Gotenberg) | `office_converter.username`, `office_converter.password` | Required. The chart stores them in the ZAC secret and injects them into both the Gotenberg container (`GOTENBERG_API_BASIC_AUTH_*`) and ZAC (`OFFICE_CONVERTER_*`), so the two can never drift apart. |
| External Solr (`solr.url` set) | `solr.username`, `solr.password` | Required for an external Solr. The chart stores them in the ZAC secret and ZAC authenticates every Solr request with them. Configure the matching user in the `security.json` of that instance yourself. |
| Solr deployed by the chart | none | The chart enables basic authentication on the `SolrCloud` resource and the Solr operator generates the credentials into the `<solrcloud>-solrcloud-security-bootstrap` secret. ZAC reads the `admin` account from that secret, so no Solr credential is a chart value. |

Both services reject unauthenticated requests, and ZAC fails to start when its credentials are missing
rather than falling back to unauthenticated requests.

The Solr operator bootstraps the `security.json` once, when Solr has none yet, and does not update it
afterwards. To change a Solr password, set it through the Solr security API as `admin` first and then
update the bootstrap secret by hand. See
[Managing the Solr search engine](https://github.com/infonl/dimpact-zaakafhandelcomponent/blob/main/docs/development/managingSolr.md)
for the Solr details, including how to read the admin password for the Solr admin UI.

## Tracing

ZAC sends its traces with OpenTelemetry (OTLP over gRPC) when `tracing.enabled` is true. Two settings decide
where the traces go, one for each hop:

```
ZAC ──OTLP──▶ OpenTelemetry collector ──▶ tracing backend, such as Tempo
    ↑                                 ↑
    tracing.endpoint                  opentelemetry-collector.config.exporters
                                      (bundled collector only)
```

To send the traces to a collector or tracing backend that already runs in the cluster, set its endpoint and leave
the bundled collector disabled:

```
--set tracing.enabled=true
--set tracing.endpoint=https://my-collector.monitoring.svc.cluster.local:4317
```

To deploy the bundled collector, leave `tracing.endpoint` empty and configure where the collector forwards the
traces to:

```
--set tracing.enabled=true
--set opentelemetry-collector.enabled=true
--set opentelemetry-collector.config.exporters.otlp.endpoint=https://tempo.monitoring.svc.cluster.local:4317
--set opentelemetry-collector.config.service.pipelines.traces.exporters={otlp}
```

For an endpoint without TLS, which is common inside a cluster, use `http://` instead of `https://`. The bundled
collector then also needs `--set opentelemetry-collector.config.exporters.otlp.tls.insecure=true`.

`opentelemetry_zaakafhandelcomponent.endpoint` is deprecated and replaced by `tracing.endpoint`. Until it is
removed, it and an enabled bundled collector still turn on tracing, and `helm install` and `helm upgrade` print a
deprecation notice.

## Changes to the helm chart

The Github workflow will perform helm-linting and will bump the version if needed. This `README.md` file is generated automatically as well.

Unit tests for the templates live in `tests/` and use [helm-unittest](https://github.com/helm-unittest/helm-unittest).
The Github workflow runs them in every pull request. To run them locally with Helm 4:

```bash
helm repo add opentelemetry https://open-telemetry.github.io/opentelemetry-helm-charts
helm repo add solr https://solr.apache.org/charts
helm plugin install https://github.com/helm-unittest/helm-unittest.git --version v1.2.1 --verify=false
helm dependency build charts/zac
helm unittest --strict charts/zac
```

Helm 4 cannot verify plugins installed from git, hence `--verify=false`. Helm 3 does not know this flag; leave it out
there.

On macOS the install script of the plugin needs GNU `sha256sum`. Install it with `brew install coreutils` and
put it first on the `PATH` during the plugin install:

```bash
PATH="$(brew --prefix coreutils)/libexec/gnubin:$PATH" helm plugin install https://github.com/helm-unittest/helm-unittest.git --version v1.2.1 --verify=false
```

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| affinity | object | `{}` | set affinity parameters |
| auth.clientId | string | `""` | Client ID and secret as defined in the Keycloak ZAC realm |
| auth.enablePkce | bool | `false` | Whether to enable PKCE (Proof Key for Code Exchange) for the OpenID Connect authorization code flow. |
| auth.realm | string | `""` |  |
| auth.secret | string | `""` |  |
| auth.server | string | `""` |  |
| auth.sslRequired | string | `""` | Whether communication with the Keycloak OpenID provider should be over HTTPS. Valid values are: "all" - to always require HTTPS, "external" - to only require HTTPS for external requests, "none" - if HTTPS is not required. This should be set to "all" in production environments. |
| autoscaling.enabled | bool | `false` |  |
| autoscaling.maxReplicas | int | `100` |  |
| autoscaling.minReplicas | int | `1` |  |
| autoscaling.targetCPUUtilizationPercentage | int | `80` |  |
| backendConfig.enabled | bool | `false` |  |
| bagApi.apiKey | string | `""` |  |
| bagApi.url | string | `""` |  |
| brpApi.apiKey | object | `{"header":"X-API-KEY","value":""}` | Optional API key for BRP authentication. When set, BRP_API_KEY is injected as a Kubernetes Secret. |
| brpApi.logLevel | string | `"INFO"` |  |
| brpApi.protocollering.doelbinding.header | string | `""` | Header name for the doelbinding value. Set to empty string to disable this header. |
| brpApi.protocollering.doelbinding.perZaaktype | bool | `false` | Set to true to require doelbinding values to be configured per zaaktype in the admin UI |
| brpApi.protocollering.doelbinding.raadpleegmet | string | `""` | Default "RaadpleegMet" doelbinding as a fall-back |
| brpApi.protocollering.doelbinding.zoekmet | string | `""` | Default "ZoekMet" doelbinding as a fall-back |
| brpApi.protocollering.enabled | bool | `false` | Set to true to enable BRP protocollering header injection |
| brpApi.protocollering.gebruiker.header | string | `""` | Header name for the gebruiker value. Set to empty string to disable this header. |
| brpApi.protocollering.originOin.header | string | `""` | Header name for the origin OIN value. Set to empty string to disable this header. |
| brpApi.protocollering.originOin.oin | string | `""` |  |
| brpApi.protocollering.systemUser | string | `"SystemUser"` |  |
| brpApi.protocollering.toepassing.header | string | `""` | Header name for the toepassing value. Set to empty string to disable this header. |
| brpApi.protocollering.toepassing.value | string | `"ZAC"` |  |
| brpApi.protocollering.verwerking.extendWithZaaktype | string | `""` | Note that for iConnect it is required to extend the verwerking register with the zaaktype. |
| brpApi.protocollering.verwerking.header | string | `""` | Header name for the verwerking value. Set to empty string to disable this header. |
| brpApi.protocollering.verwerking.register | string | `""` |  |
| brpApi.url | string | `""` |  |
| catalogusDomein | string | `"ALG"` | ZAC OpenZaak Catalogus Domein |
| contextUrl | string | `""` | External URL to the zaakafhandelcomponent. (https://zaakafhandelcomponent.example.com) |
| db.host | string | `""` | database.internal or 1.2.3.4 |
| db.name | string | `""` |  |
| db.password | string | `""` |  |
| db.user | string | `""` |  |
| extraDeploy | list | `[]` | Extra objects to deploy (value evaluated as a template) |
| extraEnv | list | `[]` | Extra environment variables of the ZAC container, for example `APP_ENV` of the integration tests |
| extraVolumeMounts | list | `[]` | Extra volume mounts of the ZAC container |
| extraVolumes | list | `[]` | Extra volumes of the ZAC pod |
| fullnameOverride | string | `""` | fullname to use |
| gemeente.code | string | `""` |  |
| gemeente.mail | string | `""` |  |
| gemeente.naam | string | `""` |  |
| global.curlImage.pullPolicy | string | `"IfNotPresent"` |  |
| global.curlImage.repository | string | `"docker.io/curlimages/curl"` | curl docker repository used throughout the chart |
| global.curlImage.tag | string | `"8.23.0@sha256:3fb7e13e5d179a845c97d78204f3f1064d1907037f26a3ebf91710571151fd93"` | curl docker tag to pull |
| image.pullPolicy | string | `"IfNotPresent"` |  |
| image.repository | string | `"ghcr.io/infonl/zaakafhandelcomponent"` |  |
| image.tag | string | `""` | Overrides the image tag whose default is the chart appVersion. |
| imagePullSecrets | list | `[]` | specifies image pull secrets |
| ingress.annotations | object | `{}` | An ingress in front of ZAC has to allow at least `maxFileSizeMB` plus multipart overhead and needs timeouts long enough to up- or download a document of that size over a slow connection. For the nginx ingress controller that means, next to any annotations of your own:   nginx.ingress.kubernetes.io/proxy-body-size: 600m   nginx.ingress.kubernetes.io/proxy-read-timeout: "1800"   nginx.ingress.kubernetes.io/proxy-send-timeout: "1800" A deployment that configures its ingress at the umbrella chart rather than per sub chart, as PodiumD does, has to apply the same annotations there instead; this sub chart never sees them. |
| ingress.className | string | `""` |  |
| ingress.enabled | bool | `false` |  |
| ingress.hosts[0].host | string | `"chart-example.local"` |  |
| ingress.hosts[0].paths[0].path | string | `"/"` |  |
| ingress.hosts[0].paths[0].pathType | string | `"ImplementationSpecific"` |  |
| ingress.tls | list | `[]` |  |
| initContainer.enabled | bool | `true` |  |
| initContainer.resources.limits.memory | string | `"256Mi"` |  |
| initContainer.resources.requests.cpu | string | `"50m"` |  |
| initContainer.resources.requests.memory | string | `"256Mi"` |  |
| initContainer.securityContext | object | `{"allowPrivilegeEscalation":false,"capabilities":{"drop":["ALL"]},"readOnlyRootFilesystem":true,"runAsGroup":10001,"runAsNonRoot":true,"runAsUser":10001}` | Security context for the curl-based init containers (read-only root filesystem is safe here) |
| javaOptions | string | `""` | JVM startup options. Defaults to "-XX:MaxRAMPercentage=75.0 -Xlog:gc::time,uptime", which leaves the heap to be sized from `resources.limits.memory` by the JVM itself. Prefer changing that limit over pinning the heap here with `-Xmx`. |
| keycloak.adminClient.id | string | `""` | Keycloak ZAC admin client name |
| keycloak.adminClient.secret | string | `""` | Keycloak ZAC admin client secret |
| klantinteractiesApi.token | string | `""` |  |
| klantinteractiesApi.url | string | `""` |  |
| kvkApi.apiKey | string | `""` |  |
| kvkApi.url | string | `""` |  |
| livenessProbe | object | `{"failureThreshold":16,"path":"/health/ready","periodSeconds":30,"timeoutSeconds":1}` | liveness probe configuration for the main ZAC container |
| livenessProbe.path | string | `"/health/ready"` | Path used for the liveness probe. Defaults to /health/ready so Kubernetes restarts ZAC automatically when the OpenZaak catalogus is unreachable for longer than failureThreshold * periodSeconds. The root cause is that the ZGW-API-Client MicroProfile REST client has no connectTimeout / readTimeout configured, causing stale TCP connections in the pool after extended outages. Revert to /health/live (and lower failureThreshold back to 3) once proper HTTP timeouts are configured on ZGW-API-Client in the ZAC application. |
| logLevel | string | `"INFO"` | Log level of ZAC: the WildFly root logger and console handler. One of DEBUG, INFO, WARN, ERROR. DEBUG logs a lot, including security-sensitive data such as session details; only use it temporarily. WildFly logs its own boot messages at INFO before this level applies. |
| mail.smtp.password | string | `""` | SMTP server password if authentication is required. Optional |
| mail.smtp.port | string | `"587"` | SMTP server port: 587 for TLS, port 25 for relaying. Required |
| mail.smtp.server | string | `""` | SMTP server host (for example, localhost or in-v3.mailjet.com). Required |
| mail.smtp.username | string | `""` | SMTP server username if authentication is required. Optional |
| maxFileSizeMB | int | `500` | Maximum size (in Mega Bytes) of documents that can be uploaded and downloaded. Uploads and downloads are streamed, so this value is bound by the temporary disk space available to ZAC rather than by the heap. See `resources.limits.ephemeral-storage` and the nginx and ingress body size settings, which all have to allow at least this much. Values above 2047 are rejected, because the documents registry expresses the size of a document as a 32 bit integer number of bytes. In practice the ceiling is around 768, the temporary file size WildFly allows through `dev.resteasy.entity.file.threshold`, which is part of the ZAC image and not of this chart. See `docs/development/documentFileSizes.md`. |
| maxInMemoryFileSizeMB | int | `80` | Maximum size (in Mega Bytes) of documents for operations that cannot stream and therefore hold the whole document in memory: converting to PDF for preview, sending as a mail attachment and editing through WebDAV. Larger documents can still be uploaded and downloaded. ZAC refuses to start when this value does not fit in the heap; it needs roughly three times this value, and may use at most half of the heap for it. The heap is 75% of `resources.limits.memory`, so with the default 1Gi limit the heap is 768 MB and the ceiling for this value is 128. Raise `resources.limits.memory` to go beyond that. |
| nameOverride | string | `""` | name to use |
| nginx.allowedHosts | string | `""` |  |
| nginx.api_proxy.bag.apikey_header_name | string | `"apikey"` |  |
| nginx.api_proxy.bag.apikey_value | string | `"test"` |  |
| nginx.api_proxy.bag.client_secret | string | `"bag_client"` |  |
| nginx.api_proxy.bag.enabled | bool | `true` |  |
| nginx.api_proxy.bag.host | string | `"bag.nl"` |  |
| nginx.api_proxy.bag.key_secret | string | `"bag_key"` |  |
| nginx.api_proxy.bag.path | string | `"/lvbag/individuelebevragingen/v2/"` |  |
| nginx.api_proxy.bag.proxy_path | string | `"/lvbag/individuelebevragingen/v2/"` |  |
| nginx.api_proxy.bag.server_secret | string | `"bag_server"` |  |
| nginx.api_proxy.bag.ssl_verify | bool | `false` |  |
| nginx.api_proxy.brp.apikey_header_name | string | `""` |  |
| nginx.api_proxy.brp.apikey_value | string | `""` |  |
| nginx.api_proxy.brp.client_secret | string | `"brp_client"` |  |
| nginx.api_proxy.brp.enabled | bool | `true` |  |
| nginx.api_proxy.brp.host | string | `"brp.nl"` |  |
| nginx.api_proxy.brp.key_secret | string | `"brp_key"` |  |
| nginx.api_proxy.brp.path | string | `"/haalcentraal/api/brp"` |  |
| nginx.api_proxy.brp.proxy_path | string | `"/haalcentraal/api/brp"` |  |
| nginx.api_proxy.brp.server_secret | string | `"brp_server"` |  |
| nginx.api_proxy.brp.ssl_verify | bool | `false` |  |
| nginx.api_proxy.certificate_secret | string | `"nginx-certs"` |  |
| nginx.api_proxy.enabled | bool | `false` |  |
| nginx.api_proxy.kvk.basisprofiel.apikey_header_name | string | `"X-Api-Key"` |  |
| nginx.api_proxy.kvk.basisprofiel.apikey_value | string | `"test"` |  |
| nginx.api_proxy.kvk.basisprofiel.client_secret | string | `"kvk_client"` |  |
| nginx.api_proxy.kvk.basisprofiel.enabled | bool | `true` |  |
| nginx.api_proxy.kvk.basisprofiel.host | string | `"kvk.nl"` |  |
| nginx.api_proxy.kvk.basisprofiel.key_secret | string | `"kvk_key"` |  |
| nginx.api_proxy.kvk.basisprofiel.path | string | `"/test"` |  |
| nginx.api_proxy.kvk.basisprofiel.proxy_path | string | `"/test"` |  |
| nginx.api_proxy.kvk.basisprofiel.server_secret | string | `"kvk_server"` |  |
| nginx.api_proxy.kvk.basisprofiel.ssl_verify | bool | `false` |  |
| nginx.api_proxy.kvk.vestigingsprofiel.apikey_header_name | string | `"X-Api-Key"` |  |
| nginx.api_proxy.kvk.vestigingsprofiel.apikey_value | string | `"test"` |  |
| nginx.api_proxy.kvk.vestigingsprofiel.client_secret | string | `"kvk_client"` |  |
| nginx.api_proxy.kvk.vestigingsprofiel.enabled | bool | `true` |  |
| nginx.api_proxy.kvk.vestigingsprofiel.host | string | `"kvk.nl"` |  |
| nginx.api_proxy.kvk.vestigingsprofiel.key_secret | string | `"kvk_key"` |  |
| nginx.api_proxy.kvk.vestigingsprofiel.path | string | `"/test"` |  |
| nginx.api_proxy.kvk.vestigingsprofiel.proxy_path | string | `"/test"` |  |
| nginx.api_proxy.kvk.vestigingsprofiel.server_secret | string | `"kvk_server"` |  |
| nginx.api_proxy.kvk.vestigingsprofiel.ssl_verify | bool | `false` |  |
| nginx.api_proxy.kvk.zoeken.apikey_header_name | string | `"X-Api-Key"` |  |
| nginx.api_proxy.kvk.zoeken.apikey_value | string | `"test"` |  |
| nginx.api_proxy.kvk.zoeken.client_secret | string | `"kvk_client"` |  |
| nginx.api_proxy.kvk.zoeken.enabled | bool | `true` |  |
| nginx.api_proxy.kvk.zoeken.host | string | `"kvk.nl"` |  |
| nginx.api_proxy.kvk.zoeken.key_secret | string | `"kvk_key"` |  |
| nginx.api_proxy.kvk.zoeken.path | string | `"/test"` |  |
| nginx.api_proxy.kvk.zoeken.proxy_path | string | `"/test"` |  |
| nginx.api_proxy.kvk.zoeken.server_secret | string | `"kvk_server"` |  |
| nginx.api_proxy.kvk.zoeken.ssl_verify | bool | `false` |  |
| nginx.autoscaling.enabled | bool | `false` |  |
| nginx.client_max_body_size | string | `"600M"` | Has to allow at least `maxFileSizeMB` plus multipart overhead. |
| nginx.enabled | bool | `false` |  |
| nginx.existingConfigmap | string | `nil` |  |
| nginx.image.pullPolicy | string | `"IfNotPresent"` |  |
| nginx.image.repository | string | `"docker.io/nginxinc/nginx-unprivileged"` |  |
| nginx.image.tag | string | `"1.31.7@sha256:09b0d3eda2aa592d2487f284519419015cab010d7df16cd0fe224b585fc60eb6"` |  |
| nginx.livenessProbe.failureThreshold | int | `3` |  |
| nginx.livenessProbe.initialDelaySeconds | int | `60` |  |
| nginx.livenessProbe.periodSeconds | int | `10` |  |
| nginx.livenessProbe.successThreshold | int | `1` |  |
| nginx.livenessProbe.timeoutSeconds | int | `5` |  |
| nginx.podLabels | object | `{}` |  |
| nginx.proxy_timeout | string | `"1800s"` | Read and send timeout towards ZAC. Uploading or downloading a document of hundreds of megabytes over a slow connection takes far longer than the nginx default of 60s. |
| nginx.readinessProbe.failureThreshold | int | `3` |  |
| nginx.readinessProbe.initialDelaySeconds | int | `30` |  |
| nginx.readinessProbe.periodSeconds | int | `10` |  |
| nginx.readinessProbe.successThreshold | int | `1` |  |
| nginx.readinessProbe.timeoutSeconds | int | `5` |  |
| nginx.replicaCount | int | `1` |  |
| nginx.resources.limits.memory | string | `"128Mi"` |  |
| nginx.resources.requests.cpu | string | `"10m"` |  |
| nginx.resources.requests.memory | string | `"32Mi"` |  |
| nginx.securityContext.capabilities.drop[0] | string | `"ALL"` |  |
| nginx.securityContext.readOnlyRootFilesystem | bool | `false` |  |
| nginx.securityContext.runAsNonRoot | bool | `true` |  |
| nginx.securityContext.runAsUser | int | `101` |  |
| nginx.service.annotations | object | `{}` |  |
| nginx.service.port | int | `80` |  |
| nginx.service.type | string | `"ClusterIP"` |  |
| nginx.topologySpreadConstraints | list | `[]` |  |
| nginx.useXForwardedHost | bool | `false` |  |
| nodeSelector | object | `{}` | set node selector parameters |
| notificationsSecretKey | string | `""` | API key for the ZGW Notificaties Consumer API integration; also needs to be configured in Open Notificaties |
| objectenApi.token | string | `""` |  |
| objectenApi.url | string | `""` |  |
| office_converter.affinity | object | `{}` |  |
| office_converter.containerPort | int | `3000` |  |
| office_converter.enabled | bool | `true` |  |
| office_converter.env.API_ENABLE_BASIC_AUTH | string | `"true"` |  |
| office_converter.env.CHROMIUM_DISABLE_ROUTES | string | `"true"` |  |
| office_converter.image.pullPolicy | string | `"IfNotPresent"` |  |
| office_converter.image.repository | string | `"docker.io/gotenberg/gotenberg"` |  |
| office_converter.image.tag | string | `"9.2.0@sha256:e1840b4c1ee113078cc153b8359433c9511ab544c1a15cd45b09f81c9329118a"` |  |
| office_converter.imagePullSecrets | list | `[]` |  |
| office_converter.name | string | `"office-converter"` |  |
| office_converter.nodeSelector | object | `{}` |  |
| office_converter.password | string | `""` | Office converter basic authentication password. Required; the office converter rejects unauthenticated requests. |
| office_converter.podAnnotations | object | `{}` |  |
| office_converter.podSecurityContext.seccompProfile.type | string | `"RuntimeDefault"` |  |
| office_converter.replicas | int | `1` |  |
| office_converter.resources.limits.memory | string | `"1Gi"` |  |
| office_converter.resources.requests.cpu | string | `"100m"` |  |
| office_converter.resources.requests.memory | string | `"512Mi"` |  |
| office_converter.securityContext.allowPrivilegeEscalation | bool | `false` |  |
| office_converter.securityContext.capabilities.drop[0] | string | `"ALL"` |  |
| office_converter.securityContext.readOnlyRootFilesystem | bool | `true` |  |
| office_converter.securityContext.runAsGroup | int | `10001` |  |
| office_converter.securityContext.runAsNonRoot | bool | `true` |  |
| office_converter.securityContext.runAsUser | int | `10001` |  |
| office_converter.service.annotations | object | `{}` |  |
| office_converter.service.port | int | `80` |  |
| office_converter.service.type | string | `"ClusterIP"` |  |
| office_converter.tolerations | list | `[]` |  |
| office_converter.topologySpreadConstraints | list | `[]` |  |
| office_converter.username | string | `""` | Office converter basic authentication user name. Required; the office converter rejects unauthenticated requests. |
| opa.affinity | object | `{}` |  |
| opa.autoscaling.enabled | bool | `false` |  |
| opa.enabled | bool | `true` |  |
| opa.image.pullPolicy | string | `"IfNotPresent"` |  |
| opa.image.repository | string | `"docker.io/openpolicyagent/opa"` |  |
| opa.image.tag | string | `"1.22.2-static@sha256:805656c845fb626b856fb4b4799d6c91e053a41eecc48537f4f1c2fd6974fbdd"` |  |
| opa.imagePullSecrets | list | `[]` |  |
| opa.name | string | `"opa"` |  |
| opa.nodeSelector | object | `{}` |  |
| opa.podAnnotations | object | `{}` |  |
| opa.podSecurityContext.seccompProfile.type | string | `"RuntimeDefault"` |  |
| opa.replicas | int | `1` |  |
| opa.resources.limits.memory | string | `"128Mi"` |  |
| opa.resources.requests.cpu | string | `"10m"` |  |
| opa.resources.requests.memory | string | `"20Mi"` |  |
| opa.securityContext.allowPrivilegeEscalation | bool | `false` |  |
| opa.securityContext.capabilities.drop[0] | string | `"ALL"` |  |
| opa.securityContext.readOnlyRootFilesystem | bool | `true` |  |
| opa.securityContext.runAsGroup | int | `10001` |  |
| opa.securityContext.runAsNonRoot | bool | `true` |  |
| opa.securityContext.runAsUser | int | `10001` |  |
| opa.service.annotations | object | `{}` |  |
| opa.service.port | int | `8181` |  |
| opa.service.type | string | `"ClusterIP"` |  |
| opa.sidecar | bool | `true` | set sidecar to true to run the opa service as a sidecar container within the ZAC pod (set to false to run as a standalone pod and service) |
| opa.tolerations | list | `[]` |  |
| opa.topologySpreadConstraints | list | `[]` |  |
| openForms.url | string | `""` | Not used at the moment. |
| opentelemetry-collector.config.receivers.jaeger | object | `{}` |  |
| opentelemetry-collector.config.receivers.prometheus | object | `{}` |  |
| opentelemetry-collector.config.receivers.zipkin | object | `{}` |  |
| opentelemetry-collector.config.service.pipelines.logs | object | `{}` |  |
| opentelemetry-collector.config.service.pipelines.metrics | object | `{}` |  |
| opentelemetry-collector.config.service.pipelines.traces.receivers[0] | string | `"otlp"` |  |
| opentelemetry-collector.enabled | bool | `false` |  |
| opentelemetry-collector.image.pullPolicy | string | `"IfNotPresent"` |  |
| opentelemetry-collector.image.repository | string | `"otel/opentelemetry-collector-contrib"` |  |
| opentelemetry-collector.image.tag | string | `"0.165.0@sha256:e40d61f10c9a617cca1ffd1be4d7e2b3a4b0f0001798ff07e58cabe82e618cea"` |  |
| opentelemetry-collector.mode | string | `"deployment"` |  |
| opentelemetry-collector.ports.jaeger-compact.enabled | bool | `false` |  |
| opentelemetry-collector.ports.jaeger-grpc.enabled | bool | `false` |  |
| opentelemetry-collector.ports.jaeger-thrift.enabled | bool | `false` |  |
| opentelemetry-collector.ports.zipkin.enabled | bool | `false` |  |
| opentelemetry-collector.presets.clusterMetrics.enabled | bool | `false` |  |
| opentelemetry-collector.replicaCount | int | `1` |  |
| organizations.bron.rsin | string | `""` | The RSIN of the Non-natural person - the organization that created the zaak. Must be a valid RSIN of 9 numbers and comply with https://nl.wikipedia.org/wiki/Burgerservicenummer#11-proef |
| organizations.verantwoordelijke.rsin | string | `""` | The RSIN of the Non-natural person - the organization that is ultimately responsible for handling a zaak or establishing a decision. Must be a valid RSIN of 9 numbers and comply with https://nl.wikipedia.org/wiki/Burgerservicenummer#11-proef |
| pabcApi.apiKey | string | `""` |  |
| pabcApi.url | string | `""` |  |
| podAnnotations | object | `{}` | pod specific annotations |
| podSecurityContext | object | `{"seccompProfile":{"type":"RuntimeDefault"}}` | pod specific security context |
| productaanvraag.claimTimeoutMinutes | int | `10` | Number of minutes after which a productaanvraag claim that was never completed (for example because ZAC was restarted) may be picked up again by a redelivered notification. |
| remoteDebug | bool | `false` | Enable Java remote debugging |
| replicaCount | int | `1` | The number of replicas to run |
| resources.limits.ephemeral-storage | string | `"4Gi"` |  |
| resources.limits.memory | string | `"2Gi"` | The JVM sizes its heap from this limit, so this is how the heap available to ZAC is set. With the default `-XX:MaxRAMPercentage=75.0` a 2Gi limit gives a 1536 MB heap, which leaves room for a `maxInMemoryFileSizeMB` of up to 256. The chart refuses to render without this limit, because it cannot otherwise tell whether the configured file size limits fit. |
| resources.requests.cpu | string | `"100m"` |  |
| resources.requests.ephemeral-storage | string | `"4Gi"` |  |
| resources.requests.memory | string | `"2Gi"` |  |
| securityContext | object | `{"allowPrivilegeEscalation":false,"capabilities":{"drop":["ALL"]},"readOnlyRootFilesystem":true,"runAsGroup":10001,"runAsNonRoot":true,"runAsUser":10001}` | generic security context |
| service.annotations | object | `{}` |  |
| service.port | int | `80` |  |
| service.type | string | `"ClusterIP"` |  |
| serviceAccount.annotations | object | `{}` | Annotations to add to the service account |
| serviceAccount.create | bool | `true` | Specifies whether a service account should be created |
| serviceAccount.name | string | `""` | The name of the service account to use. If not set and create is true, a name is generated using the fullname template |
| signaleringen.affinity | object | `{}` |  |
| signaleringen.concurrencyPolicy | string | `"Forbid"` |  |
| signaleringen.deleteOldSignaleringenSchedule | string | `"0 3 * * *"` | Schedule of the 'delete old signaleringen' send job in CRON job format |
| signaleringen.deleteOlderThanDays | string | `"14"` | Delete any signaleringen older than this number of days when the corresponding admin endpoint is called. |
| signaleringen.failedJobsHistoryLimit | int | `3` |  |
| signaleringen.imagePullSecrets | list | `[]` |  |
| signaleringen.nodeSelector | object | `{}` |  |
| signaleringen.podSecurityContext.seccompProfile.type | string | `"RuntimeDefault"` |  |
| signaleringen.resources | object | `{"limits":{"cpu":"100m","memory":"64Mi"},"requests":{"cpu":"10m","memory":"32Mi"}}` | resource requests and limits for the curl-based signaleren CronJob containers |
| signaleringen.restartPolicy | string | `"Never"` |  |
| signaleringen.securityContext | object | `{"allowPrivilegeEscalation":false,"capabilities":{"drop":["ALL"]},"readOnlyRootFilesystem":true,"runAsGroup":65532,"runAsNonRoot":true,"runAsUser":65532}` | container security context for the curl-based signaleren CronJob containers |
| signaleringen.sendZaakSignaleringenSchedule | string | `"0 2 * * *"` | Schedule of the signaleringen send zaken job in CRON job format |
| signaleringen.successfulJobsHistoryLimit | int | `1` | k8s settings for the signaleren jobs |
| signaleringen.tolerations | list | `[]` |  |
| smartDocuments.authentication | string | `""` | Authentication token |
| smartDocuments.enabled | bool | `false` | Enable SmartDocuments integration for creating a new document |
| smartDocuments.fixedUserName | string | `""` | If set this overrides the sending of the username of the user that is logged in to ZAC to SmartDocuments with a fixed value. This username is sent to SmartDocuments when creating a new document as an HTTP header. For most target environments, this should not be set, assuming that all users that are available in ZAC are also available in the SmartDocuments environment with the same username. If this setting is set, then templates in SmartDocuments cannot use user-specific values. |
| smartDocuments.url | string | `""` | URL to SmartDocuments instance. For example: https://partners.smartdocuments.com |
| smartDocuments.wizardAuthEnabled | bool | `true` | [OPTIONAL] Normal attended wizard flow started with user; when set to false no user added to the request and a special no_auth SmartDocuments URL is used |
| solr-operator.affinity | object | `{}` | affinity for solr-operator |
| solr-operator.annotations | object | `{}` | annotations for solr-operator |
| solr-operator.enabled | bool | `false` | set enabled to actually use the solr-operator helm chart |
| solr-operator.fullnameOverride | string | `"solr-operator"` | set fullname for solr-operator |
| solr-operator.image.pullPolicy | string | `"IfNotPresent"` | solr-operator imagePullPolicy |
| solr-operator.image.repository | string | `"apache/solr-operator"` | solr-operator repository |
| solr-operator.image.tag | string | `"v0.9.1@sha256:4db34508137f185d3cad03c7cf7c2b5d6533fb590822effcde9125cff5a90aa2"` | solr-operator tag |
| solr-operator.metrics.enabled | bool | `true` | enable to have solr-operator metric endpoints |
| solr-operator.nodeSelector | object | `{}` |  |
| solr-operator.solr.affinity | object | `{}` | affinity for solr in solrcloud |
| solr-operator.solr.annotations | object | `{}` | annotations for solr in solrcloud |
| solr-operator.solr.busyBoxImage.pullPolicy | string | `"IfNotPresent"` | solr busybox image imagePullPolicy |
| solr-operator.solr.busyBoxImage.repository | string | `"library/busybox"` | solr busybox image reposity |
| solr-operator.solr.busyBoxImage.tag | string | `"1.38.0-glibc@sha256:99813cb178ace2cd9c6c53ee3bddef5d2f5708aa438335111d7a9e3c5e1aaebe"` | solr busybox image tag |
| solr-operator.solr.containerSecurityContext | object | `{"allowPrivilegeEscalation":false,"capabilities":{"drop":["ALL"]}}` | securityContext for the solr container in solrcloud; the Solr Operator applies it to that container only. Capabilities and privilege escalation can only be set per container, so the init containers keep the defaults for those. |
| solr-operator.solr.enabled | bool | `true` |  |
| solr-operator.solr.image.pullPolicy | string | `"IfNotPresent"` | solr imagePullPolicy |
| solr-operator.solr.image.repository | string | `"library/solr"` | solr image repository |
| solr-operator.solr.image.tag | string | `"9.11.0-slim@sha256:54cec2ced0f2c26436605a7dd5dde5ae78f26d5c0d19a7358349d5cb71fdfc1a"` | solr image tag |
| solr-operator.solr.javaMem | string | `"-Xms512m -Xmx768m"` |  |
| solr-operator.solr.jobs.affinity | object | `{}` | affinity for jobs |
| solr-operator.solr.jobs.annotations | object | `{}` | annotations for jobs |
| solr-operator.solr.jobs.nodeSelector | object | `{}` | nodeSelector for jobs |
| solr-operator.solr.jobs.tolerations | list | `[]` | tolerations for jobs |
| solr-operator.solr.livenessProbe | object | `{"exec":{"command":["sh","-c","set -- /etc/secrets/*-solrcloud-basic-auth; [ \"$#\" -eq 1 ] && [ -r \"$1/password\" ] || { echo \"expected one *-solrcloud-basic-auth secret in /etc/secrets\" >&2; exit 1; }; scheme=http; [ \"${SOLR_SSL_ENABLED:-false}\" = true ] && scheme=https; printf 'user = \"%s:%s\"\\n' \"$(sed 's/[\\\\\"]/\\\\&/g' \"$1/username\")\" \"$(sed 's/[\\\\\"]/\\\\&/g' \"$1/password\")\" | curl -sfk -o /dev/null --max-time 4 -K - \"$scheme://localhost:${SOLR_PORT:-8983}/solr/admin/info/health\""]},"failureThreshold":6,"periodSeconds":20,"timeoutSeconds":5}` | livenessProbe override for solr in solrcloud: restarts a node whose /solr/admin/info/health fails (500 while the CoreContainer is shut down, 503 without ZooKeeper). failureThreshold 6 x 20s = 120s rides out a ZooKeeper restart. An exec probe with `curl -f`, not httpGet: with basic auth (probesRequireAuth) the Solr Operator turns an httpGet probe into `solr api -get ... | grep -v JAVA_TOOL_OPTIONS`, which passes whenever anything is printed, errors included. The credentials come from the one basic-auth secret the operator mounts under /etc/secrets and go to curl on stdin (`-K -`), not in its argv. Port and scheme follow the operator's SOLR_PORT and SOLR_SSL_ENABLED env. |
| solr-operator.solr.logLevel | string | `"INFO"` |  |
| solr-operator.solr.nodeSelector | object | `{}` | nodeSelector for solr in solrcloud |
| solr-operator.solr.podSecurityContext | object | `{"fsGroup":8983,"fsGroupChangePolicy":"OnRootMismatch","runAsGroup":8983,"runAsNonRoot":true,"runAsUser":8983,"seccompProfile":{"type":"RuntimeDefault"}}` | pod securityContext for solr in solrcloud. The Solr Operator sets no securityContext on its own init containers (cp-solr-xml, setup-zk), so they inherit this one: without it the busybox cp-solr-xml container runs as root. 8983 is the solr image's own user, which owns the existing Solr data. |
| solr-operator.solr.readinessProbe | object | `{"exec":{"command":["sh","-c","set -- /etc/secrets/*-solrcloud-basic-auth; [ \"$#\" -eq 1 ] && [ -r \"$1/password\" ] || { echo \"expected one *-solrcloud-basic-auth secret in /etc/secrets\" >&2; exit 1; }; scheme=http; [ \"${SOLR_SSL_ENABLED:-false}\" = true ] && scheme=https; printf 'user = \"%s:%s\"\\n' \"$(sed 's/[\\\\\"]/\\\\&/g' \"$1/username\")\" \"$(sed 's/[\\\\\"]/\\\\&/g' \"$1/password\")\" | curl -sfk -o /dev/null --max-time 4 -K - \"$scheme://localhost:${SOLR_PORT:-8983}/solr/admin/info/health\""]},"failureThreshold":6,"periodSeconds":10,"timeoutSeconds":5}` | readinessProbe override for solr in solrcloud: takes a node whose /solr/admin/info/health fails out of the Service. failureThreshold 6 x 10s = 60s rides out a short ZooKeeper restart, so the nodes don't all leave the Service at once. The same exec probe as the livenessProbe, for the same reason: the Solr Operator's own readiness probe has the never-failing `| grep -v` pipeline when probesRequireAuth is set. |
| solr-operator.solr.replicas | int | `3` | replicas for solr in solrcloud, should be an odd number |
| solr-operator.solr.resources | object | `{}` | resource limits and requests for solr in solrcloud |
| solr-operator.solr.startupProbe | object | `{}` |  |
| solr-operator.solr.storage.reclaimPolicy | string | `"Delete"` | solr storage reclaimPolicy |
| solr-operator.solr.storage.size | string | `"1Gi"` | solr storage size |
| solr-operator.solr.storage.storageClassName | string | `"managed-csi"` | solr storage storageClassName |
| solr-operator.solr.tolerations | list | `[]` | tolerations for solr in solrcloud |
| solr-operator.solr.topologySpreadConstraints | list | `[{"labelSelector":{"matchLabels":{"technology":"solr-cloud"}},"matchLabelKeys":["controller-revision-hash"],"maxSkew":1,"topologyKey":"kubernetes.io/hostname","whenUnsatisfiable":"DoNotSchedule"}]` | topologySpreadConstraints for solr in solrcloud |
| solr-operator.tolerations | list | `[]` |  |
| solr-operator.watchNamespaces | string | `"default"` | a comma-seperated list of namespaces to watch, watches all namespaces if empty |
| solr-operator.zookeeper-operator.affinity | object | `{}` | affinity for zookeeper-operator |
| solr-operator.zookeeper-operator.annotations | object | `{}` | annotations for zookeeper-operator |
| solr-operator.zookeeper-operator.fullnameOverride | string | `"zookeeper-operator"` | set fullname for zookeeper-operator |
| solr-operator.zookeeper-operator.hooks.image.pullPolicy | string | `"IfNotPresent"` | zookeeper-operator hooks imagePullPolicy |
| solr-operator.zookeeper-operator.hooks.image.repository | string | `"lachlanevenson/k8s-kubectl"` | zookeeper-operator hooks repository |
| solr-operator.zookeeper-operator.hooks.image.tag | string | `"v1.25.4@sha256:af5cea3f2e40138df90660c0c073d8b1506fb76c8602a9f48aceb5f4fb052ddc"` | zookeeper-operator hooks tag |
| solr-operator.zookeeper-operator.image.pullPolicy | string | `"IfNotPresent"` | zookeeper-operator imagePullPolicy |
| solr-operator.zookeeper-operator.image.repository | string | `"pravega/zookeeper-operator"` | zookeeper-operator image repository |
| solr-operator.zookeeper-operator.image.tag | string | `"0.2.15@sha256:b2bc4042fdd8fea6613b04f2f602ba4aff1201e79ba35cd0e2df9f3327111b0e"` | zookeeper-operator image tag |
| solr-operator.zookeeper-operator.nodeSelector | object | `{}` |  |
| solr-operator.zookeeper-operator.tolerations | list | `[]` | tolerations for solr-operator |
| solr-operator.zookeeper-operator.watchNamespace | string | `"default"` | a comma-seperated list of namespaces to watch, watches all namespaces if empty |
| solr-operator.zookeeper-operator.zookeeper.affinity | object | `{}` | affinity for zookeeper |
| solr-operator.zookeeper-operator.zookeeper.annotations | object | `{}` | annotations for zookeeper |
| solr-operator.zookeeper-operator.zookeeper.image.pullPolicy | string | `"IfNotPresent"` | zookeeper imagePullPolicy |
| solr-operator.zookeeper-operator.zookeeper.image.repository | string | `"pravega/zookeeper"` | zookeeper image repository |
| solr-operator.zookeeper-operator.zookeeper.image.tag | string | `"0.2.15@sha256:c498ebfb76a66f038075e2fa6148528d74d31ca1664f3257fdf82ee779eec9c8"` | zookeeper image tag |
| solr-operator.zookeeper-operator.zookeeper.nodeSelector | object | `{}` |  |
| solr-operator.zookeeper-operator.zookeeper.replicas | int | `3` | replicas for zookeeper, should be an odd number |
| solr-operator.zookeeper-operator.zookeeper.resources | object | `{}` |  |
| solr-operator.zookeeper-operator.zookeeper.storage.reclaimPolicy | string | `"Delete"` | zookeeper storage reclaimPolicy |
| solr-operator.zookeeper-operator.zookeeper.storage.size | string | `"1Gi"` | zookeeper storage size |
| solr-operator.zookeeper-operator.zookeeper.storage.storageClassName | string | `"managed-csi"` | zookeeper storageClassName |
| solr-operator.zookeeper-operator.zookeeper.tolerations | list | `[]` | tolerations for zookeeper |
| solr-operator.zookeeper-operator.zookeeper.topologySpreadConstraints | list | `[{"labelSelector":{"matchLabels":{"technology":"zookeeper"}},"matchLabelKeys":["controller-revision-hash"],"maxSkew":1,"topologyKey":"kubernetes.io/hostname","whenUnsatisfiable":"DoNotSchedule"}]` | topologySpreadConstraints for zookeeper |
| solr.createZacCore | bool | `true` | enable createZacCore to add an initContainer to the ZAC deployment that checks for and creates the zac Solr core during startup (works for both external and operator-managed Solr) |
| solr.password | string | `""` | Solr basic authentication password. Required when `solr.url` points at an external Solr; ignored for the solr-operator managed Solr. |
| solr.url | string | `""` | The location of an existing solr instance (unmanaged by this chart) to be used by zac |
| solr.username | string | `""` | Solr basic authentication user name. Required when `solr.url` points at an external Solr; configure the matching user in the `security.json` of that instance. Ignored for the solr-operator managed Solr, where the operator generates the credentials and ZAC uses the `admin` account from the operator's security bootstrap secret. |
| tmpVolumeSize | string | `"4Gi"` | Size of the emptyDir mounted at /tmp. WildFly buffers every request body to a temporary file there and ZAC streams the uploaded document from it, so this has to hold `maxFileSizeMB` for every concurrent upload. Keep `resources.requests.ephemeral-storage` and `resources.limits.ephemeral-storage` in step with it. Note that the matching 4Gi ephemeral-storage request is a scheduling requirement: a node without that much free ephemeral storage, or a namespace whose quota does not allow it, will not schedule the pod. Lower all three together when the environment cannot spare it; the cost is fewer concurrent transfers of `maxFileSizeMB`, not a lower maximum document size. |
| tolerations | list | `[]` | set toleration parameters |
| topologySpreadConstraints | list | `[{"maxSkew":1,"topologyKey":"kubernetes.io/hostname","whenUnsatisfiable":"ScheduleAnyway"}]` | set topologySpreadConstraints parameters. Note: labelSelector is automatically set by the template to match the deployment's labels |
| tracing.enabled | bool | `false` | Whether ZAC sends its traces with OpenTelemetry (OTLP over gRPC). |
| tracing.endpoint | string | `""` | OTLP endpoint that ZAC sends its traces to: an external OpenTelemetry collector or a tracing backend such as Tempo. When empty, ZAC sends its traces to the bundled `opentelemetry-collector`, which then has to be enabled. Not to be confused with `opentelemetry-collector.config.exporters.otlp.endpoint`, which is where the bundled collector forwards traces to. |
| zacInternalEndpointsApiKey | string | `""` | API key for authentication of internal ZAC endpoints |
| zgwApis.clientId | string | `""` |  |
| zgwApis.secret | string | `""` |  |
| zgwApis.url | string | `""` |  |
| ztcCacheExpirationSeconds | int | `86400` | Number of seconds after which an entry of a ZTC cache is removed when it has been neither read nor written. A type that no longer exists in the ZTC is removed from the cache only once it has not been used for this time. Default: one day. |
| ztcCacheMaxSize | int | `10000` | Maximum number of entries in each ZTC cache, such as the cache of zaaktypes or of statustypes. ZAC fills these caches with all types of the catalogus at startup, so raise this when a cache holds more types. The admin page `/rest/admin/util/cache/ztc` shows how many entries each cache holds and how much memory it uses. |
| ztcCacheRefreshIntervalSeconds | int | `3600` | Number of seconds between two refreshes of all ZTC caches in the background, so that changes that Open Zaak sends no notification for, such as a zaaktype published with the publish action, appear in ZAC. Default: one hour. 0 turns the periodic refresh off. |

----------------------------------------------
Autogenerated from chart metadata using [helm-docs v1.14.2](https://github.com/norwoodj/helm-docs/releases/v1.14.2)

