{{/*
Expand the name of the chart.
*/}}
{{- define "zaakafhandelcomponent.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "zaakafhandelcomponent.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "zaakafhandelcomponent.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a name for NGINX
We truncate at 57 chars in order to provide space for the suffix
*/}}
{{- define "zaakafhandelcomponent.nginx.name" -}}
{{ include "zaakafhandelcomponent.name" . | trunc 57 | trimSuffix "-" }}-nginx
{{- end }}

{{/*
Create a default fully qualified name for NGINX.
We truncate at 57 chars in order to provide space for the suffix
*/}}
{{- define "zaakafhandelcomponent.nginx.fullname" -}}
{{ include "zaakafhandelcomponent.fullname" . | trunc 57 | trimSuffix "-" }}-nginx
{{- end }}

{{/*
Create a default fully qualified name for solrcloud.
We truncate at 25 chars in order to provide space for the suffixes set by the solr-operator and zookeeper
*/}}
{{- define "zaakafhandelcomponent.solrcloud.fullname" -}}
{{ include "zaakafhandelcomponent.fullname" . | trunc 25 | trimSuffix "-" }}-solr
{{- end }}

{{/*
Name of the secret the Solr operator generates when it bootstraps security.json into the Solr it manages.
It holds the random passwords of the "admin", "k8s-oper" and "solr" accounts under keys of the same name.
*/}}
{{- define "zaakafhandelcomponent.solrcloud.securityBootstrapSecretName" -}}
{{ include "zaakafhandelcomponent.solrcloud.fullname" . }}-solrcloud-security-bootstrap
{{- end }}

{{/*
The SOLR_USERNAME and SOLR_PASSWORD environment variables.
For an external Solr (.Values.solr.url) they come from the ZAC secret. For the solr-operator managed Solr
they are the "admin" account the operator generates into its security bootstrap secret.
*/}}
{{- define "zaakafhandelcomponent.solr.credentialsEnv" -}}
{{- if .Values.solr.url }}
- name: SOLR_USERNAME
  valueFrom:
    secretKeyRef:
      name: {{ include "zaakafhandelcomponent.fullname" . }}
      key: SOLR_USERNAME
- name: SOLR_PASSWORD
  valueFrom:
    secretKeyRef:
      name: {{ include "zaakafhandelcomponent.fullname" . }}
      key: SOLR_PASSWORD
{{- else }}
- name: SOLR_USERNAME
  value: admin
- name: SOLR_PASSWORD
  valueFrom:
    secretKeyRef:
      name: {{ include "zaakafhandelcomponent.solrcloud.securityBootstrapSecretName" . }}
      key: admin
{{- end }}
{{- end }}

{{/*
Create a default fully qualified name for opa.
We truncate at 57 chars in order to provide space for the "-nginx" suffix
*/}}
{{- define "zaakafhandelcomponent.opa.fullname" -}}
{{ include "zaakafhandelcomponent.fullname" . | trunc 57 | trimSuffix "-" }}-opa
{{- end }}

{{/*
Create a default fully qualified name for office-converter.
We truncate at 46 chars in order to provide space for the suffix
*/}}
{{- define "zaakafhandelcomponent.office-converter.fullname" -}}
{{ include "zaakafhandelcomponent.fullname" . | trunc 46 | trimSuffix "-" }}-office-converter
{{- end }}

{{/*
Common labels
*/}}
{{- define "zaakafhandelcomponent.all.labels" -}}
helm.sh/chart: {{ include "zaakafhandelcomponent.chart" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{- define "zaakafhandelcomponent.labels" -}}
{{ include "zaakafhandelcomponent.all.labels" . }}
{{ include "zaakafhandelcomponent.selectorLabels" . }}
{{- end }}

{{- define "zaakafhandelcomponent.office-converter.labels" -}}
{{ include "zaakafhandelcomponent.all.labels" . }}
{{ include "zaakafhandelcomponent.office-converter.selectorLabels" . }}
{{- end }}

{{- define "zaakafhandelcomponent.opa.labels" -}}
{{ include "zaakafhandelcomponent.all.labels" . }}
{{ include "zaakafhandelcomponent.opa.selectorLabels" . }}
{{- end }}

{{- define "zaakafhandelcomponent.nginx.labels" -}}
{{ include "zaakafhandelcomponent.all.labels" . }}
{{ include "zaakafhandelcomponent.nginx.selectorLabels" . }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "zaakafhandelcomponent.selectorLabels" -}}
app.kubernetes.io/name: {{ include "zaakafhandelcomponent.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{- define "zaakafhandelcomponent.office-converter.selectorLabels" -}}
app.kubernetes.io/name: office-converter
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{- define "zaakafhandelcomponent.opa.selectorLabels" -}}
app.kubernetes.io/name: opa
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{- define "zaakafhandelcomponent.nginx.selectorLabels" -}}
app.kubernetes.io/name: nginx
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "zaakafhandelcomponent.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "zaakafhandelcomponent.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
The JVM startup options ZAC runs with when `javaOptions` does not override them. The heap is sized
from the container memory limit through `-XX:MaxRAMPercentage` rather than pinned with `-Xmx`, so a
change to `resources.limits.memory` moves the heap with it.
*/}}
{{- define "zaakafhandelcomponent.defaultJavaOptions" -}}
-XX:MaxRAMPercentage=75.0 -Xlog:gc::time,uptime
{{- end }}

{{/*
Converts a memory quantity to a whole number of MB. Accepts the Kubernetes suffixes (`Ki`, `Mi`,
`Gi`, `Ti`) as well as the JVM ones (`k`, `m`, `g`). The decimal Kubernetes suffixes `K`, `M`, `G`
and `T` are read as their binary neighbours, which is close enough for a sizing check.
*/}}
{{- define "zaakafhandelcomponent.memoryQuantityToMB" -}}
{{- $quantity := . | toString -}}
{{- $value := regexFind "[0-9]+" $quantity | int64 -}}
{{- $unit := regexFind "[a-zA-Z]*$" $quantity | lower -}}
{{- if or (eq $unit "g") (eq $unit "gi") -}}
{{- mul $value 1024 -}}
{{- else if or (eq $unit "t") (eq $unit "ti") -}}
{{- mul $value 1048576 -}}
{{- else if or (eq $unit "k") (eq $unit "ki") -}}
{{- div $value 1024 -}}
{{- else -}}
{{- $value -}}
{{- end -}}
{{- end }}

{{/*
Maximum heap size in MB.

The JVM sizes its heap from the memory limit of its cgroup, so that limit and the percentage of it
the heap may claim are what this derives from: `-XX:MaxRAMPercentage` of `resources.limits.memory`.
An explicit `-Xmx` in `javaOptions` still wins, because it overrides the percentage in the JVM too.
Without either the heap is whatever the node happens to offer, which the chart cannot know, so the
release is refused rather than validated against a guess.
*/}}
{{- define "zaakafhandelcomponent.maxHeapSizeMB" -}}
{{- $javaOptions := .Values.javaOptions | default (include "zaakafhandelcomponent.defaultJavaOptions" .) -}}
{{- $maxHeapOption := regexFind "-Xmx[0-9]+[kKmMgGtT]?[iI]?" $javaOptions -}}
{{- if $maxHeapOption -}}
{{- include "zaakafhandelcomponent.memoryQuantityToMB" $maxHeapOption -}}
{{- else -}}
{{- $memoryLimit := dig "limits" "memory" "" (.Values.resources | default dict) -}}
{{- if not $memoryLimit -}}
{{- fail "resources.limits.memory has to be set, because the JVM sizes its heap from the container memory limit and the chart cannot check maxInMemoryFileSizeMB against a heap it cannot determine. Set resources.limits.memory, or pin the heap with -Xmx in javaOptions." -}}
{{- end -}}
{{- $memoryLimitMB := include "zaakafhandelcomponent.memoryQuantityToMB" $memoryLimit | int64 -}}
{{- $heapPercentage := regexFind "-XX:MaxRAMPercentage=[0-9.]+" $javaOptions | regexFind "[0-9]+" | default "25" | int64 -}}
{{- div (mul $memoryLimitMB $heapPercentage) 100 -}}
{{- end -}}
{{- end }}

{{/*
Fails the release when the configured file size limits cannot be served by the configured heap.
ZAC performs the same check on startup; doing it here as well turns a crash loop into a failed
install with an actionable message.
*/}}
{{- define "zaakafhandelcomponent.validateFileSizeLimits" -}}
{{- $maxFileSizeMB := .Values.maxFileSizeMB | default 500 | int64 -}}
{{- $maxInMemoryFileSizeMB := .Values.maxInMemoryFileSizeMB | default 80 | int64 -}}
{{- if or (le $maxFileSizeMB 0) (le $maxInMemoryFileSizeMB 0) -}}
{{- fail "maxFileSizeMB and maxInMemoryFileSizeMB must both be greater than zero" -}}
{{- end -}}
{{- if gt $maxFileSizeMB 2047 -}}
{{- fail (printf "maxFileSizeMB (%d) cannot be larger than 2047, because the documents registry expresses the size of a document as a 32 bit integer number of bytes" $maxFileSizeMB) -}}
{{- end -}}
{{- if gt $maxInMemoryFileSizeMB $maxFileSizeMB -}}
{{- fail (printf "maxInMemoryFileSizeMB (%d) cannot be larger than maxFileSizeMB (%d)" $maxInMemoryFileSizeMB $maxFileSizeMB) -}}
{{- end -}}
{{- $maxHeapSizeMB := include "zaakafhandelcomponent.maxHeapSizeMB" . | int64 -}}
{{- $availableHeapMB := div $maxHeapSizeMB 2 -}}
{{- $requiredHeapMB := mul $maxInMemoryFileSizeMB 3 -}}
{{- if gt $requiredHeapMB $availableHeapMB -}}
{{- fail (printf "maxInMemoryFileSizeMB (%d) requires at least %d MB of heap but only %d MB of the %d MB heap is available for it. Either lower maxInMemoryFileSizeMB to at most %d or raise resources.limits.memory, which is what the heap is sized from." $maxInMemoryFileSizeMB $requiredHeapMB $availableHeapMB $maxHeapSizeMB (div $availableHeapMB 3)) -}}
{{- end -}}
{{- end }}

{{/*
Whether ZAC sends its traces. Until the deprecated fallback is removed, an enabled bundled
collector or the deprecated opentelemetry_zaakafhandelcomponent.endpoint also turn tracing on,
so that existing installations keep their traces. NOTES.txt warns when the fallback is used.
*/}}
{{- define "zaakafhandelcomponent.tracingEnabled" -}}
{{- if or (.Values.tracing).enabled (index .Values "opentelemetry-collector" "enabled") (.Values.opentelemetry_zaakafhandelcomponent).endpoint -}}
true
{{- end -}}
{{- end }}

{{/*
The OTLP endpoint that ZAC sends its traces to.
*/}}
{{- define "zaakafhandelcomponent.tracingEndpoint" -}}
{{- $endpoint := (.Values.tracing).endpoint | default (.Values.opentelemetry_zaakafhandelcomponent).endpoint -}}
{{- if and (not $endpoint) (index .Values "opentelemetry-collector" "enabled") -}}
{{- $endpoint = printf "http://%s-opentelemetry-collector:4317" .Release.Name -}}
{{- end -}}
{{- if not $endpoint -}}
{{- fail "tracing.enabled is true, but ZAC has no endpoint to send its traces to. Set tracing.endpoint, or enable the bundled opentelemetry-collector." -}}
{{- end -}}
{{- $endpoint -}}
{{- end }}
